# Historical syntax evidence

These unchanged receipt, logs, and parser source record the 2026-10-15 01:13 UTC syntax run. During assembly of this tools bundle, all 31 source pins were matched to the sealed coherent V2 ZIP and all four log hashes matched the receipt. The parser was not rerun.

The receipt contains historical absolute paths and toolchain hashes. Those paths are provenance, not instructions or files supplied by this bundle. A portable replay environment is not supplied. The parser calls ParseText and GetDiagnostics; it does not type-check or build YourQuest. LanguageVersion.Latest resolved to CSharp12 in Roslyn 4.8. The actual Unity compiler profile remains unverified.

The three contexts each parsed 31 complete C# files with zero syntax errors and zero syntax warnings: UNITY_EDITOR, DEVELOPMENT_BUILD, and no symbols. These 93 parses are not behavioral tests, a type build, shader validation, or native Unity approval.
