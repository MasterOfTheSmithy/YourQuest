using System;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
public static class FullFileSyntax
{
    private static int Main(string[] args)
    {
        if (args.Length != 2) throw new ArgumentException("Expected context and source file list");
        string context = args[0];
        string[] symbols;
        if (context == "editor") symbols = new[] { "UNITY_EDITOR" };
        else if (context == "development_player") symbols = new[] { "DEVELOPMENT_BUILD" };
        else if (context == "release_player") symbols = new string[0];
        else throw new ArgumentException("Unknown context");
        var options = new CSharpParseOptions(LanguageVersion.Latest, DocumentationMode.Parse,
            SourceCodeKind.Regular, symbols);
        int files = 0, errors = 0, warnings = 0;
        Console.WriteLine("PARSER\t" + typeof(CSharpSyntaxTree).Assembly.FullName);
        Console.WriteLine("LANGUAGE\t" + options.LanguageVersion);
        Console.WriteLine("CONTEXT\t" + context + "\t" + string.Join(",", symbols));
        foreach (string path in File.ReadAllLines(args[1]).Where(p => p.Length != 0))
        {
            string source = File.ReadAllText(path, Encoding.UTF8);
            var tree = CSharpSyntaxTree.ParseText(source, options, path, Encoding.UTF8);
            var diagnostics = tree.GetDiagnostics().ToArray();
            int e = diagnostics.Count(x => x.Severity == DiagnosticSeverity.Error);
            int w = diagnostics.Count(x => x.Severity == DiagnosticSeverity.Warning);
            Console.WriteLine("FILE\t" + context + "\t" + e + "\t" + w + "\t" + path);
            foreach (var diagnostic in diagnostics)
                Console.WriteLine("DIAGNOSTIC\t" + context + "\t" + diagnostic.ToString());
            files++; errors += e; warnings += w;
        }
        Console.WriteLine("SUMMARY\t" + context + "\t" + files + "\t" + errors + "\t" + warnings);
        return errors == 0 ? 0 : 1;
    }
}
