# Mesh and terrain blending: coherent V2 review candidate

## Status

This is the selected mesh/terrain blending source and its recovery evidence. It remains **review-only**. No V2 installer is provided; application and automatic production defaults remain disabled. Do not drop the payload into a live project. This package does not establish a working Unity release.

## Open the source

1. Extract `YourQuest_Coherent_Static_Contact_Review_Overlay_V2_20261015_0106.zip` into a separate review folder outside your live Unity project.
2. Open the extracted `Static_Contact_Coherent_Review_Overlay_V2_20261015_0103/README.md`.
3. The single selected source tree is its `payload/` folder. Its `SOURCE_OVERLAY_MANIFEST.json` pins all 70 files and the original-project preconditions.
4. Preserve `frozen_preimages/`, `predecessor_preimages/`, and all `evidence/` archives. Those are recovery/history, not alternate patch selections. Historical disabled installers inside the archives must not be used to install V2.

The sealed ZIP is byte-identical to the original. Its own read-only `verify_review_overlay.py` is documented in the original README; it checks package integrity without a project target. It was not executed for this combined delivery.

## Baseline and recovery requirements

Future qualification requires the exact matching captured YourQuest baseline, including project/package files and GUID/preimage state. The old October 5 checkout is not a valid substitute. Frozen candidate preimages are not the original-project preimages. Do not bypass hash failures or synthesize missing metadata/GUIDs. The main streamer's original metadata bytes are not supplied; its required hash is retained.

The full captured project/source graph is not bundled. It is unnecessary for reading this review source or running the independent portable checker, but it remains an external prerequisite for genuine Unity compilation and any eventual installation. Keep current-work backups. The preserved sealed checkpoints and manifests retain the existing recovery contract.

## Validation boundaries

- The sealed archive contains managed modeled-behavior evidence and its limitations. Its overlapping suites are not additive native coverage.
- The separate `status/historical_syntax_evidence/` records 31 complete C# files parsed in three contexts, 93 parses total, with zero errors/warnings. This is syntax-only, not type resolution or a Unity build.
- Full genuine Unity/runtime/Editor compilation, shader import, native lifecycle/resource handling, visuals, performance, original-project preflight, and an installation/rollback roundtrip remain unqualified.
- Native saved-cloud validation remains paused by the usage limit. No validation was rerouted or executed while assembling this bundle.

This is a packaging delivery. No tools, tests, Blender, Unity, installers, or source patches were run or applied for it. Only archive/content/hash checks were performed.
