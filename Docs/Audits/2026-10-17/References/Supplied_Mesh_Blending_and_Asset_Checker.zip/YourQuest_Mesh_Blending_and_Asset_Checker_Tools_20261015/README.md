# YourQuest tools bundle

Mesh/terrain blending review source, plus the portable asset checker.

## 1. Mesh and terrain blending

Open `01_Mesh_Terrain_Blending_Review/README.md`. The original coherent V2 review ZIP is preserved inside that folder, including all source, preimage checks, and recovery checkpoints. Extract that inner ZIP into a separate review folder to inspect the selected `payload/` tree.

**Status: review candidate, not installable or Unity-qualified.** There is no V2 apply command. The exact matching captured project baseline is required for future native qualification; the old October 5 checkout must not be substituted. The large source-graph baseline is not part of this tools bundle.

Recorded validation includes 31 complete C# files parsed in three contexts with zero syntax errors/warnings (93 parses). That is not a type build, a behavioral-test count, or a Unity test. Native saved-cloud validation is still paused by the usage limit. Read the folder README for remaining gates.

## 2. Portable asset checker

Open `02_Portable_Asset_Checker/QUICKSTART.md`, then `DECISION_GUIDE.md`. This folder is already extracted and preserves all 44 original files byte for byte. It contains three independent helpers: continuous contact checking, position/triangle association, and texture-budget inventory.

Requires an existing Python 3.10+ interpreter; no third-party packages, Unity, Blender, network access, or original model packs are needed for its bundled software tests and two evidence replays. Python is not included.

When you choose to run it, open a terminal in `02_Portable_Asset_Checker`:

```sh
python toolkit.py list
python toolkit.py test all
```

Use `python3` instead of `python` where appropriate, or `py -3` on Windows if its launcher is installed. These are optional user-run commands; nothing was run for this delivery.

Recorded evidence: 123 helper tests and 11 launcher tests passed on Linux/CPython 3.12.14. Windows was not run or certified. A passing test/replay command does not approve an asset: the bundled contact case intentionally reproduces a known FAIL, association evidence is partial, and texture estimates are theoretical rather than measured VRAM. Regenerating the actual texture ledger requires the three separately supplied original model packs.

## Integrity and delivery scope

`PACKAGE_MANIFEST.json` identifies both original ZIPs and records how they were packaged. `SHA256SUMS.json` hashes every file in this combined bundle except itself. Source packages and active projects were left unchanged. Package assembly verified archive CRCs, original manifests, extracted checker bytes, and syntax-receipt source/log pins. No tool/test execution, installation, patch application, Blender, or Unity work was performed for this delivery.

The nested blending archive includes historical test executables and disabled installers as unchanged recovery evidence. Do not execute historical files merely because they are present. The current selected source and its status are identified above.
