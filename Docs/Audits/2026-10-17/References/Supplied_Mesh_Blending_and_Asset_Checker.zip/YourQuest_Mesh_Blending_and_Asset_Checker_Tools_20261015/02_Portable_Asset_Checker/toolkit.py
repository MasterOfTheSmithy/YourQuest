#!/usr/bin/env python3
"""Run the three independent CPU helper suites with this Python interpreter."""

import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TOOLS = {
    "contact": {
        "folder": "contact_v1",
        "purpose": "Continuous underside/heightfield contact; bank-toe remains FAIL.",
        "test": ("-m", "unittest", "discover", "-s", "tests", "-v"),
        "replay": ("replay_bank_toe.py",),
    },
    "association": {
        "folder": "association_v1",
        "purpose": "Position-only triangle association; replay covers 22 witnesses.",
        "test": ("-m", "unittest", "-v", "test_triangle_association"),
        "replay": ("replay_witnesses.py",),
    },
    "texture": {
        "folder": "texture_budget_v1",
        "purpose": "Encoded-image identity and hypothetical mip payload budgets.",
        "test": ("-m", "unittest", "-v", "test_texture_budget"),
    },
}


def run_tool(name, action):
    """Do not import helper modules together or use the caller's directory."""
    tool = TOOLS[name]
    workdir = ROOT / "tools" / tool["folder"]
    if not workdir.is_dir():
        print("Missing helper directory: " + str(workdir), file=sys.stderr)
        return 2
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONUTF8"] = "1"
    # No site packages are needed. Each helper gets its own process and cwd.
    command = [sys.executable, "-B", "-S", *tool[action]]
    print("\n=== " + name + " / " + action + " ===", flush=True)
    try:
        result = subprocess.run(command, cwd=workdir, env=environment, check=False)
    except OSError as error:
        print("Could not start helper: " + str(error), file=sys.stderr)
        return 2
    print("=== " + name + ": process exit " + str(result.returncode) + " ===", flush=True)
    return result.returncode


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("list", help="Show the independent tools and their scope")
    tests = commands.add_parser("test", help="Run isolated helper unit tests")
    tests.add_argument("tool", choices=("all", *TOOLS), nargs="?", default="all")
    replay = commands.add_parser("replay", help="Print bundled actual-case replay JSON")
    replay.add_argument("tool", choices=("all", "contact", "association"))
    args = parser.parse_args(argv)
    if sys.version_info < (3, 10):
        parser.error("This combined toolkit needs an existing Python 3.10 or newer.")
    if args.action == "list":
        for name, tool in TOOLS.items():
            print(name + " [" + tool["folder"] + "]: " + tool["purpose"])
        print("No combined asset PASS is produced. Read DECISION_GUIDE.md.")
        return 0
    names = list(TOOLS) if args.tool == "all" else [args.tool]
    if args.action == "replay":
        names = [name for name in names if "replay" in TOOLS[name]]
    print("Helper checks only. Art, native/runtime and performance gates remain independent.", flush=True)
    results = [run_tool(name, args.action) for name in names]
    if any(code != 0 for code in results):
        print("One or more helper processes failed; inspect the output above.", file=sys.stderr)
        return 1
    print("Selected helper checks completed; this is not an asset-readiness approval.", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nInterrupted; remaining helpers were not run.", file=sys.stderr)
        raise SystemExit(130)
