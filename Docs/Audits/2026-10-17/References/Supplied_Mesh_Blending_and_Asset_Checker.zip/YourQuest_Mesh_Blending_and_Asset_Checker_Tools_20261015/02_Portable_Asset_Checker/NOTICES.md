# Preservation and licensing

This toolkit contains frozen copies of these three delivered helper packages:

- YourQuest_Exact_Contact_Preflight_V1_20261015.zip
- YourQuest_Triangle_Association_V1_Helper_20261015.zip
- YourQuest_SharedTexture_BudgetLedger_20261015.zip

All files from each archive are preserved byte for byte in its separate versioned
tool folder. `INPUTS.json` maps each file to its original archive member and records
the archive/file hashes. The upstream ZIP containers are not duplicated inside
this ZIP. Original README, provenance, validation and historical report files are
retained without rewriting their claims or dates.

The supplied archives contained no separate LICENSE or COPYING file. No original
license was removed, replaced or invented. This repackaging does not assert a new
third-party redistribution license or ownership of the user's original assets.
Any notices embedded in source or documentation remain intact. Python is not
bundled. No third-party dependency, binary or original full model pack is bundled.

Only the launcher, its small tests, this toolkit's guide/notices, and package-level
manifests/verification were added. Original helpers and active assets were not
modified.
