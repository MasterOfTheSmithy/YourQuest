# Which gate answers your question?

Passing one gate does not pass the others. The launcher runs software regression
checks and does not combine them into an asset-readiness score.

## 1. Is a chosen underside continuously within its support limits?

Use **contact**. Supply explicit underside and support triangles in world XYZ
metres, Z up, with the required declarations and unchanged gap limits. The support
must be a single-valued triangulated heightfield. The helper checks continuous
piecewise-linear gap extrema and complete supplied-domain coverage. Ambiguous
support, degenerate geometry and unsupported workloads fail closed.

This cannot establish that you chose the correct/complete underside or host,
correct transforms, physical accuracy, volumetric collision, or moving contact.
The bundled bank-toe case has full supplied coverage but **contact FAIL**:
`clast_02` exceeds the +3 mm upper limit by about 0.596424 mm. A green regression
test means that known failure was reproduced accurately.

Start with `tools/contact_v1/README.md` and
`tools/contact_v1/fixtures/flat_pass.json` for the input contract.

## 2. Which source triangle/corners correspond to imported positions?

Use **association**. Inputs must already share a coordinate frame and metre units.
The helper requires a unique cyclic correspondence, strict component error
`< 1e-5 m`, and one-to-one assignments. Rounded coordinate keys are not a final
validity gate. Ambiguous matches, reversed winding, reused source triangles and
boundary equality are rejected. Full coverage is required by default.

The actual bundled evidence deliberately requests diagnostic subset mode:
22 imported witnesses against all 884 source candidates, with 862 source triangles
unmatched. This is **PARTIAL position-only evidence**, not a fresh whole-mesh
verification. The historical complete FBX gate is separate archived evidence.
UV, normal, tangent, handedness, material, dependency and native gates remain
independent. Do not weaken them because position association succeeds.

Start with `tools/association_v1/README.md`. This toolkit does not automatically
integrate the matcher into any exporter or existing verifier.

## 3. Which encoded images repeat, and what are hypothetical mip payloads?

Use **texture**. The helper inventories supported PNG image bytes in ZIPs and GLBs,
confirms exact byte identity, and calculates explicitly hypothetical format/mip
payloads. Actual byte and metadata inspection is distinct from assumptions about
runtime allocation. Source/export packaging unions are distinct from residency.

The historical three-pack ledger has five unique source images, five unique GLB
material images and six in their packaging union. A five-resource full-mip
scenario is about 26.667 MiB RGBA8 or 6.667 MiB BC7/BC5 payload. Those calculations
are not measured GPU memory, compression quality, Unity resource sharing, peak
usage, headroom or frame time. The native renderer and import settings were not
tested. BC1 is an arithmetic comparison, not a quality recommendation.

Start with `tools/texture_budget_v1/report/report.md`. To create fresh real-asset
evidence you need the original three packs and the pinned manifest. Running the
synthetic tests alone does not regenerate that ledger.

## What still needs separate evidence?

Art review, source/export completeness, all relevant mesh attributes, dependency
closure, engine importer behavior, scene placement and actual target-native
runtime/performance testing. No helper changes their approval state. Bank toe
remains CONTACT_HELD / limited WIP; lee deposit and root triplet remain limited
WIP in the preserved ledger context.

These utilities are additive diagnostics. They edit no active asset, fix no art,
and bypass no native Unity gate. Original full model packs, Blender files, exports,
textures and third-party binaries are not included in this small toolkit.
