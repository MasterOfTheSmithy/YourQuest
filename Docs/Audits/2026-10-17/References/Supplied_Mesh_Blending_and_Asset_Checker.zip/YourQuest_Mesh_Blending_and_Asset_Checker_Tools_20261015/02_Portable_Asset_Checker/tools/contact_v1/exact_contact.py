#!/usr/bin/env python3
"""Read-only, stdlib-only XY triangle-overlay contact preflight. Python >=3.10."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import sys

SCHEMA = "yq_exact_contact_input_v1"
VERSION = "1.0.0"
DEFAULT_TOLERANCES = {
    "min_projected_double_area_m2": "1e-14",
    "gap_uncertainty_m": "0",
    "coverage_uncertainty_m2": "0",
}
WORK_LIMITS = {"triangles_per_surface": 5000, "pair_checks": 1000000,
               "exact_intersections": 100000, "overlay_vertices": 250000,
               "hole_fragments": 20000, "input_bytes": 8*1024*1024,
               "numeric_characters": 128, "decimal_exponent_magnitude": 100}


class InvalidInput(ValueError):
    pass


def rational(value):
    """Exact decimal JSON interpretation; API floats use their shortest repr."""
    if isinstance(value, bool) or not isinstance(value, (int, float, str, Decimal, Q)):
        raise InvalidInput("Coordinates and tolerances must be finite numbers or decimal strings")
    try:
        if isinstance(value, Q):
            if max(value.numerator.bit_length(), value.denominator.bit_length()) > 1024:
                raise ValueError("rational input exceeds numeric workload bound")
            result = value
        else:
            s = str(value)
            if len(s) > WORK_LIMITS["numeric_characters"]:
                raise ValueError("numeric string exceeds workload bound")
            decimal = Decimal(s)
            if not decimal.is_finite() or abs(decimal.adjusted()) > WORK_LIMITS["decimal_exponent_magnitude"]:
                raise ValueError("decimal exponent exceeds workload bound or number is not finite")
            result = Q(decimal)
        if not math.isfinite(float(result)):
            raise ValueError("not finite")
        return result
    except (ValueError, ArithmeticError) as exc:
        raise InvalidInput(f"Invalid finite numeric value: {value!r}") from exc


def load_input(path):
    def constant(x):
        raise InvalidInput(f"Non-finite JSON constant: {x}")
    def unique_object(items):
        out = {}
        for key, value in items:
            if key in out:
                raise InvalidInput(f"Duplicate JSON object key: {key}")
            out[key] = value
        return out
    # Read one byte past the bound rather than trusting a potentially stale stat.
    with Path(path).open("rb") as source:
        raw = source.read(WORK_LIMITS["input_bytes"]+1)
    if len(raw) > WORK_LIMITS["input_bytes"]:
        raise InvalidInput("Input exceeds the 8 MiB workload limit")
    return json.loads(raw.decode("utf-8"), parse_float=Decimal,
                      parse_constant=constant, object_pairs_hook=unique_object)


def orient(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def twice_area(poly):
    if len(poly) < 3:
        return Q(0)
    return abs(sum((orient(poly[0], poly[i], poly[i+1])
                    for i in range(1, len(poly)-1)), Q(0)))


def clean(poly):
    out = []
    for p in poly:
        if not out or p != out[-1]:
            out.append(p)
    if len(out) > 1 and out[0] == out[-1]:
        out.pop()
    return out


def halfplane(poly, a, b, sign=1):
    """Closed halfplane, exact signs. Never inflate an edge by an epsilon."""
    out = []
    if not poly:
        return out
    for p, q in zip(poly, poly[1:]+poly[:1]):
        dp, dq = sign*orient(a, b, p), sign*orient(a, b, q)
        ip, iq = dp >= 0, dq >= 0
        if ip:
            out.append(p)
        if ip != iq:
            t = dp / (dp-dq)
            out.append((p[0]+t*(q[0]-p[0]), p[1]+t*(q[1]-p[1])))
    return clean(out)


def intersect(poly, triangle):
    for a, b in zip(triangle, triangle[1:]+triangle[:1]):
        poly = halfplane(poly, a, b)
        if not poly:
            break
    return poly


def subtract(poly, triangle):
    """Partition convex polygon minus a CCW triangle into convex pieces."""
    out = []
    for a, b in zip(triangle, triangle[1:]+triangle[:1]):
        outside = halfplane(poly, a, b, -1)
        if twice_area(outside):
            out.append(outside)
        poly = halfplane(poly, a, b)
        if not twice_area(poly):
            break
    return out


def id_key(value):
    return (0, value) if isinstance(value, int) else (1, value)


@dataclass
class Triangle:
    face_id: object
    vertices: tuple
    component: str | None = None

    def __post_init__(self):
        self.xy = [v[:2] for v in self.vertices]
        self.det = orient(*self.xy)
        if self.det < 0:
            self.vertices = (self.vertices[0], self.vertices[2], self.vertices[1])
            self.xy = [v[:2] for v in self.vertices]
            self.det = -self.det
        # Monotone float rounding cannot turn a real bbox overlap into disjoint
        # boxes. Exact geometry is still used after this coarse rejection.
        self.bbox = (float(min(p[0] for p in self.xy)), float(max(p[0] for p in self.xy)),
                     float(min(p[1] for p in self.xy)), float(max(p[1] for p in self.xy)))

    def height(self, xy):
        a, b, c = self.vertices
        return a[2] + (orient(a, xy, c)*(b[2]-a[2]) +
                       orient(a, b, xy)*(c[2]-a[2])) / self.det


def boxes_overlap(a, b):
    return not (a[1] < b[0] or b[1] < a[0] or a[3] < b[2] or b[3] < a[2])


def parse_triangles(rows, label, min_area):
    if not isinstance(rows, list) or not rows:
        raise InvalidInput(f"{label} must be a nonempty array of explicitly selected triangles")
    if len(rows) > WORK_LIMITS["triangles_per_surface"]:
        raise InvalidInput(f"{label} exceeds triangle workload limit")
    result, seen = [], set()
    for row in rows:
        if not isinstance(row, dict) or "id" not in row or "vertices" not in row:
            raise InvalidInput(f"{label}: each triangle needs id and vertices")
        fid = row["id"]
        if isinstance(fid, bool) or not isinstance(fid, (str, int)) or fid == "":
            raise InvalidInput(f"{label}: face IDs must be nonempty strings or integers")
        if (type(fid), fid) in seen:
            raise InvalidInput(f"{label}: duplicate face ID {fid!r}")
        seen.add((type(fid), fid))
        v = row["vertices"]
        if not isinstance(v, list) or len(v) != 3 or any(not isinstance(p, list) or len(p) != 3 for p in v):
            raise InvalidInput(f"{label} face {fid!r}: exactly three XYZ vertices required")
        component = row.get("component")
        if component is not None and (not isinstance(component, str) or not component):
            raise InvalidInput(f"{label} face {fid!r}: component must be a nonempty string")
        tri = Triangle(fid, tuple(tuple(rational(c) for c in p) for p in v), component)
        if tri.det <= min_area:
            raise InvalidInput(f"{label} face {fid!r}: invalid or near-degenerate XY projection; "
                               f"double area {float(tri.det):.17g} <= {float(min_area):.17g} m^2")
        result.append(tri)
    return sorted(result, key=lambda t: id_key(t.face_id))


def exact_string(q):
    return f"{q.numerator}/{q.denominator}"


def point_json(p):
    return [float(c) for c in p]


class WorkBudget:
    def __init__(self):
        self.counts = {k: 0 for k in ["pair_checks", "exact_intersections", "overlay_vertices", "hole_fragments"]}

    def add(self, name, amount=1):
        self.counts[name] += amount
        if self.counts[name] > WORK_LIMITS[name]:
            raise InvalidInput(f"Workload limit exceeded: {name}; partition the explicit task into smaller validated domains")


def surface_issue(host, budget):
    """Validate whole supplied support: no area overlap or disagreeing seams."""
    ordered = sorted(host, key=lambda t: (t.bbox[0], id_key(t.face_id)))
    checked = 0
    for i, a in enumerate(ordered):
        for j in range(i+1, len(ordered)):
            b = ordered[j]
            budget.add("pair_checks")
            if b.bbox[0] > a.bbox[1]:
                break
            if not boxes_overlap(a.bbox, b.bbox):
                continue
            checked += 1
            budget.add("exact_intersections")
            polygon = intersect(a.xy, b.xy)
            if not polygon:
                continue
            area = twice_area(polygon)/2
            if area:
                return {"code": "SUPPORT_PROJECTED_INTERIOR_OVERLAP", "host_face_ids": [a.face_id, b.face_id],
                        "overlap_area_m2": float(area), "witness_xy_m": point_json(polygon[0]),
                        "detail": "Overhang, duplicate faces, or an ambiguous overlapping domain; no envelope is chosen."}, checked
            for xy in polygon:
                za, zb = a.height(xy), b.height(xy)
                if za != zb:
                    return {"code": "SUPPORT_MULTIVALUED_SEAM", "host_face_ids": [a.face_id, b.face_id],
                            "witness_xy_m": point_json(xy), "heights_m": [float(za), float(zb)],
                            "height_difference_exact_m": exact_string(za-zb),
                            "detail": "Even a boundary point must have one support height; no seam mismatch is silently tolerated."}, checked
    return None, checked


def witness(under, host, xy):
    uz, hz = under.height(xy), host.height(xy)
    gap = uz-hz
    return (gap, id_key(under.face_id), id_key(host.face_id), xy,
            {"underside_face_id": under.face_id, "host_face_id": host.face_id,
             "component": under.component, "xy_m": point_json(xy),
             "underside_xyz_m": point_json((*xy, uz)), "support_xyz_m": point_json((*xy, hz)),
             "gap_m": float(gap), "exact": {"xy_m": [exact_string(c) for c in xy],
                                             "gap_m": exact_string(gap)}})


def extreme(records, maximum=False):
    if not records:
        return None
    return min(records, key=lambda r: (-r[0] if maximum else r[0], r[1], r[2], r[3]))


def range_status(lo, hi, limits, uncertainty):
    if lo < limits[0]-uncertainty or hi > limits[1]+uncertainty:
        return "FAIL"
    if lo < limits[0]+uncertainty or hi > limits[1]-uncertainty:
        return "UNVERIFIED"
    return "PASS"


def preflight(document):
    """Return JSON-compatible report. Input is never changed; no asset IO."""
    budget = WorkBudget()
    report = {"schema": "yq_exact_contact_report_v1", "tool_version": VERSION,
              "status": "UNVERIFIED", "method": "Exact rational XY triangle overlay and affine height extrema",
              "coverage_status": "UNVERIFIED", "support_status": "UNVERIFIED",
              "extrema_scope": "Covered intersections of explicitly designated underside faces only",
              "native": "NOT_RUN", "issues": [], "work_limits": dict(WORK_LIMITS), "work_used": budget.counts}
    try:
        if not isinstance(document, dict) or document.get("schema") != SCHEMA:
            raise InvalidInput(f"schema must be {SCHEMA}")
        for key, expected in [("coordinate_space", "WORLD_XYZ_METRES"),
                              ("underside_designation", "EXPLICIT_TRIANGLES"),
                              ("support_model", "SINGLE_VALUED_TRIANGULATED_HEIGHTFIELD")]:
            if document.get(key) != expected:
                raise InvalidInput(f"{key} must explicitly be {expected}")
        config = document.get("tolerances", {})
        if not isinstance(config, dict) or set(config)-set(DEFAULT_TOLERANCES):
            raise InvalidInput("Unknown or invalid tolerance configuration")
        tol = {k: rational(config.get(k, v)) for k, v in DEFAULT_TOLERANCES.items()}
        if any(v < 0 for v in tol.values()):
            raise InvalidInput("Tolerances cannot be negative")
        limits = document.get("gap_limits_m")
        if not isinstance(limits, list) or len(limits) != 2:
            raise InvalidInput("gap_limits_m must specify [minimum, maximum]")
        limits = [rational(v) for v in limits]
        if limits[0] > limits[1]:
            raise InvalidInput("gap_limits_m minimum exceeds maximum")
        report["gap_limits_m"] = [float(v) for v in limits]
        report["tolerances"] = {k: float(v) for k, v in tol.items()}
        report["exact_configuration"] = {"gap_limits_m": [exact_string(v) for v in limits],
                                         "tolerances": {k: exact_string(v) for k, v in tol.items()}}
        underside = parse_triangles(document.get("underside"), "underside", tol["min_projected_double_area_m2"])
        host = parse_triangles(document.get("support"), "support", tol["min_projected_double_area_m2"])
        report["counts"] = {"underside_triangles": len(underside), "support_triangles": len(host)}
        issue, checked = surface_issue(host, budget)
        report["counts"]["support_bbox_candidate_pairs_checked"] = checked
        if issue:
            report["issues"].append(issue)
            return report
        report["support_status"] = "PASS_SINGLE_VALUED_ON_DECLARED_DOMAIN"
        all_extrema, rows, coverage_holes = [], [], []
        total_area, total_uncovered = Q(0), Q(0)
        overlay_polygons = 0
        for tri in underside:
            records, candidates = [], []
            covered_area = Q(0)
            for ht in host:
                budget.add("pair_checks")
                if not boxes_overlap(tri.bbox, ht.bbox):
                    continue
                budget.add("exact_intersections")
                polygon = intersect(tri.xy, ht.xy)
                if not polygon:
                    continue
                area = twice_area(polygon)/2
                if area:
                    candidates.append(ht)
                    covered_area += area
                    overlay_polygons += 1
                budget.add("overlay_vertices", len(polygon))
                records.extend(witness(tri, ht, xy) for xy in polygon)
            area = tri.det/2
            missing = area-covered_area
            if missing < 0:
                raise InvalidInput("Internal overlay area exceeded underside area after support validation")
            row = {"underside_face_id": tri.face_id, "component": tri.component,
                   "projected_area_m2": float(area), "covered_area_m2": float(covered_area),
                   "uncovered_area_m2": float(missing), "fully_covered": missing == 0,
                   "evaluated_overlay_vertices": len(records)}
            if missing:
                pieces = [tri.xy]
                for ht in candidates:
                    next_pieces = []
                    for p in pieces:
                        budget.add("exact_intersections")
                        parts = subtract(p, ht.xy)
                        budget.add("hole_fragments", len(parts))
                        next_pieces.extend(parts)
                    pieces = next_pieces
                if sum((twice_area(p)/2 for p in pieces), Q(0)) != missing:
                    raise InvalidInput("Internal uncovered-polygon partition disagreed with exact area")
                holes = []
                for p in pieces:
                    xy = tuple(sum((v[i] for v in p), Q(0))/len(p) for i in range(2))
                    holes.append({"underside_face_id": tri.face_id, "component": tri.component,
                                  "area_m2": float(twice_area(p)/2), "area_exact_m2": exact_string(twice_area(p)/2),
                                  "polygon_xy_m": [point_json(v) for v in p],
                                  "witness_underside_xyz_m": point_json((*xy, tri.height(xy))),
                                  "witness_xy_exact_m": [exact_string(c) for c in xy]})
                coverage_holes.extend(holes)
            if records:
                low, high = extreme(records), extreme(records, True)
                all_extrema.extend((low, high))
                row.update(minimum=low[4], maximum=high[4],
                           covered_gap_status=range_status(low[0], high[0], limits, tol["gap_uncertainty_m"]))
            else:
                row.update(minimum=None, maximum=None, covered_gap_status="UNVERIFIED")
            rows.append(row)
            total_area += area
            total_uncovered += missing
        report["faces"] = rows
        report["coverage"] = {"sum_face_projected_area_m2": float(total_area),
                              "sum_face_uncovered_area_m2": float(total_uncovered),
                              "uncovered_area_exact_m2": exact_string(total_uncovered),
                              "holes": coverage_holes,
                              "note": "Areas are face-wise sums, not the union of possibly overlapping underside faces."}
        report["counts"]["positive_area_overlay_polygons"] = overlay_polygons
        report["counts"]["evaluated_overlay_vertices"] = sum(r["evaluated_overlay_vertices"] for r in rows)
        report["coverage_status"] = ("PASS" if not total_uncovered else
                                     "FAIL" if total_uncovered > tol["coverage_uncertainty_m2"] else "UNVERIFIED")
        if all_extrema:
            lo, hi = extreme(all_extrema), extreme(all_extrema, True)
            report.update(minimum=lo[4], maximum=hi[4],
                          contact_status=range_status(lo[0], hi[0], limits, tol["gap_uncertainty_m"]))
        else:
            report.update(minimum=None, maximum=None, contact_status="UNVERIFIED")
        states = [report["coverage_status"], report["contact_status"]]
        report["status"] = "FAIL" if "FAIL" in states else "UNVERIFIED" if "UNVERIFIED" in states else "PASS"
        if total_uncovered:
            report["issues"].append({"code": "UNCOVERED_UNDERSIDE_DOMAIN", "detail": "No host height exists in the reported holes; no extrapolation or sampling fallback was used."})
        if report["contact_status"] == "FAIL":
            report["issues"].append({"code": "CONTACT_LIMIT_EXCEEDED", "detail": "The exact covered-domain gap extrema violate the explicit limits beyond the declared uncertainty."})
        elif report["contact_status"] == "UNVERIFIED" and all_extrema:
            report["issues"].append({"code": "CONTACT_LIMIT_UNCERTAINTY", "detail": "The declared gap uncertainty intersects a contact limit."})
    except (InvalidInput, ArithmeticError) as exc:
        report["issues"].append({"code": "INVALID_OR_UNSUPPORTED_INPUT", "detail": str(exc)})
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Explicit world-space triangle JSON")
    parser.add_argument("--output", type=Path, help="Create a NEW report file; refuses to overwrite")
    parser.add_argument("--min-projected-double-area-m2")
    parser.add_argument("--gap-uncertainty-m")
    parser.add_argument("--coverage-uncertainty-m2")
    args = parser.parse_args(argv)
    try:
        doc = load_input(args.input)
        if isinstance(doc, dict):
            config = doc.setdefault("tolerances", {})
            if not isinstance(config, dict):
                raise InvalidInput("tolerances must be an object")
            for key in DEFAULT_TOLERANCES:
                value = getattr(args, key)
                if value is not None:
                    config[key] = value
        report = preflight(doc)
        report["input_sha256"] = hashlib.sha256(args.input.read_bytes()).hexdigest()
    except (OSError, ValueError, RecursionError) as exc:
        report = {"schema": "yq_exact_contact_report_v1", "status": "UNVERIFIED",
                  "issues": [{"code": "INPUT_READ_ERROR", "detail": str(exc)}]}
    payload = json.dumps(report, indent=2, sort_keys=True, allow_nan=False)+"\n"
    if args.output:
        try:
            with args.output.open("x", encoding="utf-8") as out:
                out.write(payload)
        except OSError as exc:
            print(f"Cannot create new report: {exc}", file=sys.stderr)
            return 2
    else:
        sys.stdout.write(payload)
    return {"PASS": 0, "FAIL": 1, "UNVERIFIED": 2}[report["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
