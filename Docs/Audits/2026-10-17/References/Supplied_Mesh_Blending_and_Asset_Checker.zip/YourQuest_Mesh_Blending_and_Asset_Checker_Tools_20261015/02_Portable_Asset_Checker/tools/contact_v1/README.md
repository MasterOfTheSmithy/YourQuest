# YourQuest exact contact preflight v1

A small, read-only Python 3.10+ helper for one question: **does every explicitly
selected underside triangle remain within the allowed vertical gap range of a
single-valued triangulated support surface, over its entire XY footprint?**
No installs, Blender, NumPy, SciPy, Unity, or assets are required to run it.

## The defect this closes

The bank-toe construction checked seven points per bottom triangle. Those samples
passed `[-8, +3] mm`; the largest sampled gap was `+2.975725 mm`. They did not bound
the continuous surface. Full triangle overlay gives:

- Minimum: **−7.92216071096181 mm**
- Maximum: **+3.596424180701237 mm**, exceeding +3 mm by **0.596424180701237 mm**
- Maximum witness: original underside face **121**, host face **522**
- Witness XY: **(0.05943506630657226, −0.10051444323811647) m**
- Complete coverage: **54 underside triangles**, **1,024 host triangles**
- Only `clast_02` fails. The candidate has identical underside vertices and
  connectivity, checked independently against its captured geometry and recipe.

`reports/bank_toe_replay.json` is the canonical actual-case report. Its regression
check passes because it reproduces the known defect; **the asset contact gate
remains FAIL**. Neither geometry nor the original support limits were changed.
It cross-checks all 14 component ranges against the archived contact correction,
plus the witness IDs/XY. Differences from the archived float calculation are
about 10^-17 m. Old source files, receipts, and archives are untouched.

## Run

From this extracted directory:

```sh
python exact_contact.py fixtures/flat_pass.json
python exact_contact.py fixtures/bank_toe.json --output new_contact_report.json
python replay_bank_toe.py --output new_replay_report.json
python -m unittest discover -s tests -v
```

The contact CLI exits **0 PASS**, **1 FAIL**, **2 UNVERIFIED**. The bank-toe command
is expected to exit 1. The replay exits 0 only when the known failed contact gate
and archived extrema are reproduced. Reports are printed to stdout unless
`--output` names a **new** file; existing files, including inputs, are never
replaced. No files are changed by the importable `preflight(document)` function.

Optional independent re-extraction from the original available evidence:

```sh
python replay_bank_toe.py --source-root /path/to/shared_clast_recipe_benchmark_v1_20261015 --output new_source_verified_replay.json
```

This checks all nine pinned source hashes, reruns the read-only JSON extraction,
and requires byte-identical fixture and provenance outputs. Without this option,
the bundled immutable extraction is replayed; source assets are not reopened.
The canonical supplied report was generated with this source verification.

## Input contract

See `fixtures/flat_pass.json` for a complete minimal input. Required fields:

- `schema`: `yq_exact_contact_input_v1`
- `coordinate_space`: `WORLD_XYZ_METRES` (Z up; coordinates already transformed)
- `underside_designation`: `EXPLICIT_TRIANGLES`
- `support_model`: `SINGLE_VALUED_TRIANGULATED_HEIGHTFIELD`
- `gap_limits_m`: explicit `[minimum, maximum]`; positive gap means clearance,
  negative gap means embedding
- `underside` and `support`: nonempty arrays of `{id, vertices}` with three XYZ
  vertices per face. IDs are unique within each array, either integers or strings.
  An optional `component` string is carried into underside witnesses.

Triangles are explicitly selected by the caller, never inferred from normals or
sample hits. The host domain is exactly the union of the supplied closed XY
triangles; there is no implicit infinite ground or extrapolation. Disconnected
host domains and holes are supported. Underside faces are checked separately;
overlapping underside projections are allowed because each face is explicitly
identified. Reported total areas are face-wise sums, not their projected union.
The helper cannot prove that a caller supplied the correct or complete underside,
the right host, correct units, or already-applied transforms.

## Method and conservative failures

1. Reject nonfinite/malformed coordinates, non-triangles, duplicate IDs, missing
   declarations, degenerate/near-degenerate XY projections, or exceeded budgets.
2. Validate the **entire supplied host**, including regions outside the query.
   Positive-area projected overlap is UNVERIFIED, even for coplanar duplicates.
   Disagreeing heights at shared boundary points/edges are UNVERIFIED, however
   small. No upper/lower envelope is silently selected. Reversed winding is fine.
3. Clip each underside XY triangle against every relevant host triangle using
   exact rational half-plane predicates. On each overlap polygon, the gap is
   affine, so its extrema occur at polygon vertices. Edge/point contacts are
   included as extrema candidates, but cannot establish area coverage.
4. Since support interiors do not overlap, exact overlap-area sums establish
   coverage. Missing area is partitioned into explicit uncovered polygons with
   interior witness XY/underside XYZ and face IDs. Samples never prove coverage.
5. Report min/max witnesses, exact rational XY/gap strings, per-face ranges,
   coverage, and independent support/contact/overall statuses.

Unsupported host overhangs, multi-valued seams, ambiguous duplicate domains and
invalid projections return UNVERIFIED rather than skipping triangles. Uncovered
undersides normally FAIL. Extrema from partially covered inputs describe only
the covered intersections; they never certify the missing region.

## Explicit tolerances

Set `tolerances` in JSON or use the corresponding CLI switches:

- `min_projected_double_area_m2` / `--min-projected-double-area-m2`: default
  `1e-14`. Faces at or below this positive-area threshold are UNVERIFIED, not
  discarded. Set to 0 to allow all exactly nondegenerate projections.
- `gap_uncertainty_m` / `--gap-uncertainty-m`: default 0. A scalar externally
  assessed uncertainty band around computed extrema. A limit reached by that
  band is UNVERIFIED; a violation beyond it FAILS. It never silently widens a
  passing threshold. With zero uncertainty, exact equality to a limit passes.
- `coverage_uncertainty_m2` / `--coverage-uncertainty-m2`: default 0. A positive
  uncovered area at or below this threshold is UNVERIFIED; larger holes FAIL.
  A small hole is never converted to complete coverage.

No geometric epsilon expands triangle edges, ignores seam disagreements, or
merges holes. Negative/unknown tolerances are rejected. Canonical bank-toe limits
stay `[-0.008, 0.003] m` and both uncertainty settings stay zero.

## Numerical and scope limits

“Exact” refers to rational arithmetic over the **recorded input coordinates**.
JSON decimal lexemes are parsed as exact decimals. Programmatic Python floats
use their shortest decimal representation, not their underlying binary fraction.
The captured float32/float64 source values have already been rounded upstream;
no method here recovers unrecorded precision or measures physical accuracy.
Human-friendly report numbers are rounded floats; rational witness strings carry
the exact represented result. The uncertainty setting is not an automatic error
propagation model for vertex quantization, terrain movement, or source transforms.

This is a fixed-coordinate piecewise-linear heightfield preflight, not general
3D mesh collision, volumetric penetration, moving geometry, a manifold proof,
material validation, or a Unity/native contact test. No such results are claimed.

Hard fail-closed workload ceilings: 8 MiB input; 5,000 triangles per surface;
1,000,000 pair checks; 100,000 exact intersection/subtraction operations;
250,000 overlay vertices; 20,000 generated hole fragments; 128 characters per
numeric value and decimal exponents within ±100. Programmatic Fraction inputs
are bounded to 1,024-bit numerator/denominator. Exceeding a bound is UNVERIFIED.
These bound work counts, not a promised wall-clock time. Exact fractions can be
costly. Validate smaller explicit domains if a ceiling is reached; do not omit
host overlap checks across a proposed domain split.

## Verification and contents

The stdlib unittest suite covers analytic slopes and crossings, inclusive limits,
interior/outside-domain holes, boundary-only hits, winding/order changes,
overhang/duplicate/seam rejection, degenerate/nonfinite inputs, explicit
uncertainties, workload caps, CLI immutability/exit codes, and the actual bank-toe
regression. One test additionally compares **100 seeded random cases** against an
independent contained-vertex/edge-intersection oracle (no production clipping).

- `exact_contact.py`: standalone utility and CLI
- `extract_bank_toe.py`: read-only original-case extractor
- `replay_bank_toe.py`: regression and archived-report cross-check
- `fixtures/`: actual input/provenance, copied archive correction, five small
  positive/negative examples
- `tests/`: analytic, adversarial, independent randomized and actual-case checks
- `reports/`: canonical replay and recorded verification
- `MANIFEST.json`: packaged-file sizes and SHA-256 hashes

The previous Blender verifier and offline diagnosis provided the overlay method;
this version removes their NumPy/SciPy/Blender dependency, makes the explicit
underside contract reusable, and adds complete-domain validation and coverage.
