"""Stdlib regressions. Attribute comparisons below are synthetic TEST controls only."""

import copy
import json
import math
from pathlib import Path
import unittest

from triangle_association import (AssociationError, CYCLIC, MAX_TRIANGLES,
                                  POSITION_LIMIT_M, associate_triangle_positions)
from replay_witnesses import ReplayError, replay, rounded_key

T = [[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]]


def shifted(triangle, offset):
    return [[p[0] + offset, p[1], p[2]] for p in triangle]


def attribute_control(source, imported):
    """Separate unchanged original per-corner checks; never called by matcher."""
    all_values = imported["uv"] + imported["normal"] + imported["tangent"]
    if not all(math.isfinite(x) for x in all_values):
        return False
    if not max(abs(a - b) for a, b in zip(source["uv"], imported["uv"])) < 1e-6:
        return False
    for name, limit in (("normal", .0025), ("tangent", .005)):
        a, b = source[name][:3], imported[name][:3]
        an, bn = math.sqrt(sum(x*x for x in a)), math.sqrt(sum(x*x for x in b))
        if an == 0 or not abs(bn - 1) < 2e-5:
            return False
        angle = math.acos(max(-1., min(1., sum(x*y for x, y in zip(a, b))/(an*bn))))
        if not angle < limit:
            return False
    return (abs(abs(imported["tangent"][3]) - 1) < 1e-6
            and imported["tangent"][3] == source["tangent"][3])


class AssociationTests(unittest.TestCase):
    def reject(self, code, source, imported, **kwargs):
        with self.assertRaises(AssociationError) as caught:
            associate_triangle_positions(source, imported, **kwargs)
        self.assertEqual(code, caught.exception.code)

    def test_identical_positions_unique_full_bijection(self):
        result = associate_triangle_positions([T], [T])
        self.assertEqual("COMPLETE", result.coverage)
        self.assertEqual((), result.unmatched_source_triangles)
        self.assertEqual((0, 1, 2), result.matches[0].imported_to_source_corners)
        self.assertEqual(0., result.matches[0].max_position_component_error_m)

    def test_cross_rounding_boundary_positive(self):
        source, imported = copy.deepcopy(T), copy.deepcopy(T)
        source[0][0], imported[0][0] = 4.99e-6, 5.01e-6
        self.assertNotEqual(rounded_key(source), rounded_key(imported))
        result = associate_triangle_positions([source], [imported])
        self.assertLess(result.matches[0].max_position_component_error_m, 1e-5)

    def test_negative_rounding_boundary_positive(self):
        source, imported = copy.deepcopy(T), copy.deepcopy(T)
        source[0][0], imported[0][0] = -4.99e-6, -5.01e-6
        self.assertNotEqual(rounded_key(source), rounded_key(imported))
        self.assertEqual(1, len(associate_triangle_positions([source], [imported]).matches))

    def test_outside_tolerance_negative(self):
        imported = copy.deepcopy(T)
        imported[0][2] = 1.01e-5
        self.reject("NO_MATCH", [T], [imported])

    def test_strict_boundary_below_equal_above(self):
        for value, accepted in ((math.nextafter(1e-5, 0.), True),
                                (1e-5, False), (math.nextafter(1e-5, math.inf), False)):
            for sign in (-1, 1):
                with self.subTest(value=value, sign=sign):
                    imported = copy.deepcopy(T)
                    imported[0][2] = sign * value
                    if accepted:
                        self.assertEqual(1, len(associate_triangle_positions([T], [imported]).matches))
                    else:
                        self.reject("NO_MATCH", [T], [imported])

    def test_original_componentwise_not_euclidean_metric(self):
        imported = copy.deepcopy(T)
        imported[0] = [9e-6, 9e-6, 9e-6]
        self.assertGreater(math.sqrt(sum(x*x for x in imported[0])), POSITION_LIMIT_M)
        self.assertEqual(9e-6, associate_triangle_positions([T], [imported]).matches[0].max_position_component_error_m)

    def test_all_cyclic_corner_orders_preserve_winding(self):
        for permutation in CYCLIC:
            with self.subTest(permutation=permutation):
                result = associate_triangle_positions([T], [[T[i] for i in permutation]])
                self.assertEqual(permutation, result.matches[0].imported_to_source_corners)

    def test_all_reversed_corner_orders_rejected(self):
        for permutation in ((0, 2, 1), (2, 1, 0), (1, 0, 2)):
            with self.subTest(permutation=permutation):
                self.reject("REVERSED_WINDING", [T], [[T[i] for i in permutation]])

    def test_permuted_triangle_order_independent_of_corner_winding(self):
        other = shifted(T, 10.)
        result = associate_triangle_positions([T, other], [[other[1], other[2], other[0]], T])
        self.assertEqual([1, 0], [m.source_triangle for m in result.matches])
        self.assertEqual((1, 2, 0), result.matches[0].imported_to_source_corners)
        result2 = associate_triangle_positions([other, T], [T, other])
        self.assertEqual([1, 0], [m.source_triangle for m in result2.matches])

    def test_repeated_source_geometry_ambiguous(self):
        self.reject("AMBIGUOUS_TRIANGLE", [T, T], [T, T])

    def test_nearcoincident_source_geometry_ambiguous(self):
        close = shifted(T, 0.5e-5)
        self.reject("AMBIGUOUS_TRIANGLE", [T, close], [T, close])

    def test_reverse_candidate_does_not_hide_coincident_ambiguity(self):
        reverse = [T[0], T[2], T[1]]
        self.reject("AMBIGUOUS_TRIANGLE", [T, reverse], [T, reverse])

    def test_repeated_corners_ambiguous(self):
        degenerate = [T[0], T[0], T[1]]
        self.reject("AMBIGUOUS_CORNERS", [degenerate], [degenerate])

    def test_nearcoincident_corners_ambiguous(self):
        narrow = [[0., 0., 0.], [0.25e-5, 0., 0.], [0., 1., 0.]]
        self.reject("AMBIGUOUS_CORNERS", [narrow], [narrow])

    def test_duplicate_destination_assignments_rejected_globally(self):
        self.reject("DUPLICATE_ASSIGNMENT", [T, shifted(T, 10.)], [T, T])

    def test_no_greedy_used_filter_or_global_guess(self):
        source = [T, shifted(T, 1.5e-5)]
        imported = [shifted(T, -0.25e-5), shifted(T, .75e-5)]
        self.reject("AMBIGUOUS_TRIANGLE", source, imported)
        self.reject("AMBIGUOUS_TRIANGLE", source, list(reversed(imported)))

    def test_nonfinite_coordinates_in_both_inputs_rejected(self):
        for value in (math.nan, math.inf, -math.inf):
            bad = copy.deepcopy(T)
            bad[0][0] = value
            for source, imported in (([bad], [T]), ([T], [bad])):
                with self.subTest(value=value, source=source is bad):
                    self.reject("NONFINITE_INPUT", source, imported)

    def test_malformed_inputs_and_empty_mesh_rejected(self):
        for bad in ([], [T[:2]], [[[0., 1.]] * 3], [[[True, 0., 0.]] * 3],
                    [[["0", 0., 0.]] * 3], [[ [10**500, 0., 0.] ] * 3]):
            with self.subTest(bad=repr(bad)[:60]):
                self.reject("INVALID_INPUT", bad, [T])

    def test_tolerance_cannot_be_widened_or_nonfinite(self):
        for tolerance in (0., -1., 1.00001e-5, math.inf, math.nan, True, "1e-5"):
            with self.subTest(tolerance=tolerance):
                self.reject("INVALID_TOLERANCE", [T], [T], position_tolerance_m=tolerance)

    def test_tolerance_may_be_tightened_explicitly(self):
        imported = copy.deepcopy(T)
        imported[0][2] = .5e-5
        self.reject("NO_MATCH", [T], [imported], position_tolerance_m=.25e-5)

    def test_complete_coverage_required_by_default(self):
        self.reject("COUNT_MISMATCH", [T, shifted(T, 10.)], [T])

    def test_explicit_subset_is_labeled_and_unused_sources_reported(self):
        result = associate_triangle_positions([T, shifted(T, 10.)], [T], require_full_coverage=False)
        self.assertEqual("PARTIAL", result.coverage)
        self.assertEqual((1,), result.unmatched_source_triangles)
        self.reject("INVALID_INPUT", [T], [T], require_full_coverage=1)

    def test_workload_limits_fail_before_pair_scan(self):
        self.reject("WORKLOAD_LIMIT", [T] * 1001, [T] * 1001)
        self.reject("INVALID_INPUT", [T] * (MAX_TRIANGLES + 1), [T])

    def test_inputs_not_mutated_on_success_or_failure(self):
        source, imported = [copy.deepcopy(T)], [copy.deepcopy(T)]
        before = copy.deepcopy((source, imported))
        associate_triangle_positions(source, imported)
        self.assertEqual(before, (source, imported))
        imported[0][0][2] = .1
        before = copy.deepcopy((source, imported))
        self.reject("NO_MATCH", source, imported)
        self.assertEqual(before, (source, imported))

    def test_geometry_does_not_approve_bad_uv_normal_tangent_or_sign(self):
        source = {"uv": [0., 0.], "normal": [0., 0., 1.], "tangent": [1., 0., 0., 1.]}
        self.assertTrue(attribute_control(source, source))
        variants = [dict(source, uv=[1e-6, 0.]),
                    dict(source, normal=[math.sin(.003), 0., math.cos(.003)]),
                    dict(source, tangent=[math.cos(.006), math.sin(.006), 0., 1.]),
                    dict(source, tangent=[1., 0., 0., -1.]),
                    dict(source, normal=[0., 0., 2.]),
                    dict(source, uv=[math.nan, 0.])]
        for imported_attributes in variants:
            with self.subTest(attributes=imported_attributes):
                self.assertEqual(1, len(associate_triangle_positions([T], [T]).matches))
                self.assertFalse(attribute_control(source, imported_attributes))


class RecordedWitnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = json.loads(Path(__file__).with_name("recorded_case.json").read_text())

    def test_all_actual_witnesses_against_all_source_candidates(self):
        report = replay(self.fixture)
        self.assertEqual("PASS_RECORDED_POSITION_WITNESSES_ONLY", report["status"])
        self.assertEqual(22, report["actual_imported_triangles_replayed"])
        self.assertEqual(884, report["source_candidates_checked_per_witness"])
        self.assertEqual(862, report["unreplayed_source_triangles"])
        self.assertEqual("PARTIAL", report["coverage"])
        self.assertTrue(all(v == "NOT_RUN" for v in report["independent_gates_this_run"].values()))
        self.assertFalse(report["original_files_verified_unchanged"])

    def test_triangle_16_actual_saved_rounding_miss(self):
        witness = next(w for w in self.fixture["witnesses"] if w["export_triangle"] == 16)
        self.assertNotEqual(rounded_key(witness["source_positions"]), rounded_key(witness["imported_positions"]))
        result = associate_triangle_positions([witness["source_positions"]], [witness["imported_positions"]])
        self.assertEqual(3.725290298461914e-8, result.matches[0].max_position_component_error_m)

    def test_actual_witnesses_reordered_and_cyclic(self):
        source = [t["positions"] for t in self.fixture["source_triangles"]]
        witnesses = list(reversed(self.fixture["witnesses"]))
        imported = [[w["imported_positions"][i] for i in (1, 2, 0)] for w in witnesses]
        result = associate_triangle_positions(source, imported, require_full_coverage=False)
        self.assertEqual([w["source_triangle"] for w in witnesses], [m.source_triangle for m in result.matches])
        self.assertTrue(all(m.imported_to_source_corners == (1, 2, 0) for m in result.matches))

    def test_fixture_does_not_manufacture_all_imported_corners(self):
        self.assertEqual(22, len(self.fixture["witnesses"]))
        self.assertEqual(884, self.fixture["recorded_full_gate"]["geometry_summary"]["triangles"])
        self.assertEqual("NOT_RUN_PAUSED", self.fixture["recorded_full_gate"]["native"])

    def test_tampered_recorded_corner_mapping_rejected(self):
        fixture = copy.deepcopy(self.fixture)
        fixture["witnesses"][0]["recorded_corner_associations"][0]["source_loop"] = -1
        with self.assertRaises(ReplayError):
            replay(fixture)


if __name__ == "__main__":
    unittest.main(verbosity=2)
