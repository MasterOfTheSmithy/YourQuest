# YourQuest Triangle Position Association v1

A small read-only, Python-standard-library helper for the rounded-coordinate
lookup failure seen in the Surface Root Triplet FBX diagnostic. It does not
change the exporter, repair a mesh, edit inputs, invoke Blender, or run Unity.

## Verified result and limits

The bundled fixture preserves **22 actual imported/source triangle witnesses**
from the saved diagnostic, including triangle 16, plus **all 884 source
candidate triangles**. This helper uniquely associates all 22 witnesses without
using rounded keys as a validity gate. The largest replayed component error is
`4.470348358154297e-8 m`; triangle 16 is `3.725290298461914e-8 m`.

This is a **partial position-correspondence replay**, not a fresh verification of
all 884 imported triangles. The other 862 imported triplets are not reconstructed
or invented. The prior complete 884-triangle/2,652-corner FBX verification remains
separate historical evidence; its overall `3.371387720108032e-7 m` maximum is not
the maximum of this smaller replay. No UV, normal, tangent, handedness, material,
dependency, or native/runtime gate is rerun by the position helper.

Original source/export files and five diagnostic inputs were SHA-256 checked
before and after the replay. The fixture's coordinates and corner IDs were also
compared directly with their original JSON records. See
`verified_witness_replay.json` and `input_hashes_before.json`.

## Run

Python 3.9+; no package installation, Blender, or network needed. From this folder:

```sh
python -B -m unittest -v test_triangle_association.py
python -B replay_witnesses.py
```

To additionally verify unchanged original bytes and exact fixture provenance:

```sh
python -B replay_witnesses.py --original-root /path/to/surface_root_triplet_v4_lod0_closure_20261015
```

The CLI only reads files and prints JSON to standard output. Exit 0 means the
recorded position witnesses passed; exit 1 means HOLD. Without `--original-root`,
the report explicitly says original-file hashes/projection were not checked.
It does not ask for a Blender/Unity installation or edit existing gate reports.

## Callable contract

```python
from triangle_association import associate_triangle_positions

mapping = associate_triangle_positions(
    source_triangles_m, imported_triangles_m,
    position_tolerance_m=1e-5,
)
```

Both inputs are lists/tuples of triangles, each containing three finite XYZ
positions, in the **same coordinate frame, in metres**. Caller-provided unit
conversion/transforms must already have happened; the helper performs none.
Output triangle indices are input-list ordinals, not application triangle IDs.
For every imported triangle, `imported_to_source_corners[i]` gives the source
corner index for imported corner `i`. Neither input is reordered or mutated.

- The original position metric is maximum absolute XYZ component error.
  Every component must be **strictly less than `1e-5 m` (10 micrometres)**.
  Equality is rejected. No epsilon is added. The optional tolerance may only
  tighten this limit, never widen it.
- All six corner permutations and all source candidates are checked. Exactly
  one correspondence must exist, and it must be a cyclic permutation. Triangle
  list reorderings and cyclic corner rotations pass; reversed winding fails.
- Coincident/near-coincident source triangles and ambiguous corner mappings
  fail closed. The helper does not use UVs or a greedy/global solver to guess.
  This intentionally can hold geometry that another domain-specific resolver
  might disambiguate.
- Already-used source triangles remain visible during local matching. A second
  imported triangle assigning to the same source then fails the global one-to-one
  check. Full source coverage and equal counts are required by default.
- `require_full_coverage=False` is an explicit diagnostic-subset option. It still
  validates unique assignments and reports unused source triangles and `PARTIAL`
  coverage. Do not use a partial result as a complete-mesh pass.
- Search is exhaustive rather than hash/bin-based, capped at 4,096 triangles
  per input and 1,000,000 triangle pairs. Each pair checks at most six permutations
  of nine components. Oversized/empty/malformed/nonfinite inputs fail closed.
  If an accelerator is added later, it may only collect candidates; neither a
  rounded-key hit nor a miss can establish the final answer.

## Keep independent gates independent

For an intentional future integration, replace only rounded-key association
with the returned correspondence. Compare each mapped imported/source loop using
the existing strict checks: UV `< 1e-6`, normal angle `< .0025 rad`, tangent angle
`< .005 rad`, unit-vector checks, and exact tangent handedness. Keep original
material, dependency, topology/connectivity, and native qualification checks.
Do not reinterpret a position association as any of those approvals.

The tests include synthetic bad-UV, bad-normal, bad-tangent, and handedness
controls: position association passes, while the separate unchanged attribute
checks reject the bad data. Those controls are test demonstrations, not fresh
claims about the FBX's imported attributes. Original verifier files remain
unchanged; this package is additive and has no automatic integration or repair.

## Package

- `triangle_association.py`: small reusable position-only matcher
- `replay_witnesses.py`: bounded, read-only saved-evidence CLI
- `test_triangle_association.py`: positive/negative, boundary, winding,
  ambiguity, global-assignment, nonfinite, immutability and recorded-case tests
- `recorded_case.json`: actual saved witnesses, source candidates and provenance
- `verified_witness_replay.json`: this run's scoped results and unchanged hashes
- `verification.json`, `SHA256SUMS.json`: test/package verification receipts

No original `.blend`, FBX, GLB, or texture binary is included in the ZIP.
