import copy
from fractions import Fraction as F
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import exact_contact as ec


def triangle(fid, coordinates, z=0, component=None):
    row = {'id': fid, 'vertices': [list(p) if len(p) == 3 else [*p, z] for p in coordinates]}
    if component:
        row['component'] = component
    return row


def square(x0=0, y0=0, x1=1, y1=1, z=0, start=0):
    return [triangle(start, [(x0,y0),(x1,y0),(x1,y1)], z),
            triangle(start+1, [(x0,y0),(x1,y1),(x0,y1)], z)]


def case(underside=None, support=None, limits=None, tolerances=None):
    return {'schema': ec.SCHEMA, 'coordinate_space': 'WORLD_XYZ_METRES',
            'underside_designation': 'EXPLICIT_TRIANGLES',
            'support_model': 'SINGLE_VALUED_TRIANGULATED_HEIGHTFIELD',
            'gap_limits_m': [-1,1] if limits is None else limits,
            'tolerances': {} if tolerances is None else tolerances,
            'underside': square(z=0) if underside is None else underside,
            'support': square(z=0) if support is None else support}


def brute_extrema(document):
    """Independent oracle: enumerate contained vertices and segment crossings.

    No polygon clipping or production geometry helper is called here.
    All fixtures are small integer/rational input, so this oracle is exact too.
    """
    def cross(a,b):
        return a[0]*b[1]-a[1]*b[0]
    def minus(a,b):
        return (a[0]-b[0],a[1]-b[1])
    def contains(p,t):
        s=[cross(minus(t[(i+1)%3],t[i]),minus(p,t[i])) for i in range(3)]
        return all(x>=0 for x in s) or all(x<=0 for x in s)
    def height(p,t):
        # Solve independent plane coefficients, rather than production's
        # barycentric formulation evaluated via repeated orient calls.
        a,b,c=t
        ux,uy,uz=[b[i]-a[i] for i in range(3)]
        vx,vy,vz=[c[i]-a[i] for i in range(3)]
        det=ux*vy-uy*vx
        gx=(uz*vy-uy*vz)/det
        gy=(ux*vz-uz*vx)/det
        return a[2]+gx*(p[0]-a[0])+gy*(p[1]-a[1])
    gaps=[]
    for ur in document['underside']:
        a=[tuple(F(str(v)) for v in p) for p in ur['vertices']]
        for hr in document['support']:
            b=[tuple(F(str(v)) for v in p) for p in hr['vertices']]
            points={p[:2] for p in a if contains(p,b)} | {p[:2] for p in b if contains(p,a)}
            for i in range(3):
                p,q=a[i],a[(i+1)%3]
                r=minus(q,p)
                for j in range(3):
                    c,d=b[j],b[(j+1)%3]
                    s=minus(d,c)
                    den=cross(r,s)
                    if den:
                        t=cross(minus(c,p),s)/den
                        u=cross(minus(c,p),r)/den
                        if 0<=t<=1 and 0<=u<=1:
                            points.add((p[0]+t*r[0],p[1]+t*r[1]))
            gaps.extend(height(p,a)-height(p,b) for p in points)
    return min(gaps),max(gaps)


class AnalyticTests(unittest.TestCase):
    def test_flat_complete_domain(self):
        r=ec.preflight(case())
        self.assertEqual((r['status'],r['coverage_status']),('PASS','PASS'))
        self.assertEqual(r['minimum']['gap_m'],0)
        self.assertEqual(r['coverage']['uncovered_area_exact_m2'],'0/1')

    def test_affine_slope_extrema(self):
        u=[triangle(7, [(0,0,0),(1,0,2),(0,1,-3)])]
        h=[triangle(11, [(0,0,0),(1,0,1),(0,1,1)])]
        r=ec.preflight(case(u,h,[-5,2]))
        self.assertEqual(r['status'],'PASS')
        self.assertEqual((r['minimum']['gap_m'],r['maximum']['gap_m']),(-4,1))

    def test_support_slope_crossing_extremum_not_underside_vertex(self):
        corners=[(0,0,0),(2,0,0),(2,2,0),(0,2,0)]
        h=[triangle(i,[corners[i],corners[(i+1)%4],(1,1,-1)]) for i in range(4)]
        r=ec.preflight(case(square(0,0,2,2),h,[-.5,.5]))
        self.assertEqual(r['status'],'FAIL')
        self.assertEqual(r['maximum']['gap_m'],1)
        self.assertEqual(r['maximum']['xy_m'],[1,1])

    def test_edge_edge_crossing_extrema(self):
        u=[triangle(1,[(0,1,0),(2,1,0),(1,3,0)])]
        h=[triangle(2,[(0,0,0),(2,0,0),(2,2,-2)]),triangle(3,[(0,0,0),(2,2,-2),(0,2,0)])]
        r=ec.preflight(case(u,h,[-9,9]))
        lo,hi=brute_extrema(case(u,h))
        self.assertEqual(F(r['maximum']['exact']['gap_m']),hi)
        self.assertEqual(F(r['minimum']['exact']['gap_m']),lo)
        self.assertEqual(r['coverage_status'],'FAIL')

    def test_limits_are_inclusive_without_uncertainty(self):
        for z in ['-0.008','0.003']:
            r=ec.preflight(case(square(z=z),limits=['-0.008','0.003']))
            self.assertEqual(r['status'],'PASS')

    def test_both_limit_violations(self):
        for z in ['-0.0080000000001','0.0030000000001']:
            r=ec.preflight(case(square(z=z),limits=['-0.008','0.003']))
            self.assertEqual(r['status'],'FAIL')

    def test_uncertainty_does_not_silently_widen_limits(self):
        for z in ['0.00295','0.00305']:
            r=ec.preflight(case(square(z=z),limits=[-.008,.003],tolerances={'gap_uncertainty_m':'0.0001'}))
            self.assertEqual(r['status'],'UNVERIFIED')
        self.assertEqual(ec.preflight(case(square(z='.0032'),limits=[-.008,.003],tolerances={'gap_uncertainty_m':'.0001'}))['status'],'FAIL')

    def test_full_outside_domain(self):
        r=ec.preflight(case(square(2,2,3,3)))
        self.assertEqual(r['status'],'FAIL')
        self.assertIsNone(r['minimum'])
        self.assertEqual(r['coverage']['sum_face_uncovered_area_m2'],1)
        self.assertEqual(len(r['coverage']['holes']),2)

    def test_partial_outside_domain_has_hole_witnesses(self):
        r=ec.preflight(case(square(0,0,2,2)))
        self.assertEqual(r['coverage']['sum_face_uncovered_area_m2'],3)
        for h in r['coverage']['holes']:
            x,y,_=h['witness_underside_xyz_m']
            self.assertTrue(x>1 or y>1)

    def test_interior_hole_despite_outer_corner_coverage(self):
        host=[]
        for y in range(3):
            for x in range(3):
                if (x,y)!=(1,1):
                    host.extend(square(x,y,x+1,y+1,start=len(host)))
        r=ec.preflight(case(square(0,0,3,3),host))
        self.assertEqual(r['coverage']['sum_face_uncovered_area_m2'],1)
        self.assertEqual(r['status'],'FAIL')
        for h in r['coverage']['holes']:
            x,y,_=h['witness_underside_xyz_m']
            self.assertTrue(1<x<2 and 1<y<2)

    def test_tiny_hole_is_unverified_never_pass(self):
        h=square(0,0,'0.999999999999',1)
        r=ec.preflight(case(support=h,tolerances={'coverage_uncertainty_m2':'1e-9'}))
        self.assertEqual(r['status'],'UNVERIFIED')
        self.assertGreater(r['coverage']['sum_face_uncovered_area_m2'],0)

    def test_edge_only_contact_still_uncovered(self):
        r=ec.preflight(case(square(1,0,2,1)))
        self.assertEqual(r['coverage_status'],'FAIL')
        self.assertIsNotNone(r['maximum'])
        self.assertEqual(r['coverage']['sum_face_uncovered_area_m2'],1)

    def test_point_only_contact_still_uncovered(self):
        r=ec.preflight(case(square(1,1,2,2)))
        self.assertEqual(r['coverage_status'],'FAIL')
        self.assertIsNotNone(r['maximum'])

    def test_touching_host_components_at_equal_point(self):
        h=square()+square(1,1,2,2,start=2)
        self.assertEqual(ec.preflight(case(support=h))['status'],'PASS')

    def test_disjoint_host_components_allowed(self):
        h=square()+square(3,3,4,4,start=2)
        self.assertEqual(ec.preflight(case(support=h))['status'],'PASS')

    def test_t_junction_same_height_allowed(self):
        h=[triangle(0,[(0,0),(1,0),(1,1)]),triangle(1,[(0,0),(1,1),(0,1)]),
           triangle(2,[(1,0),(2,0),(1,.5)]),triangle(3,[(1,.5),(2,0),(2,1)]),triangle(4,[(1,.5),(2,1),(1,1)])]
        self.assertEqual(ec.preflight(case(square(0,0,2,1),h))['status'],'PASS')

    def test_subtolerance_seam_disagreement_rejected(self):
        h=[triangle(0,[(0,0),(1,0),(1,1)]),triangle(1,[(0,0),(1,1),(0,1)],z='1e-30')]
        r=ec.preflight(case(support=h))
        self.assertEqual(r['status'],'UNVERIFIED')
        self.assertEqual(r['issues'][0]['code'],'SUPPORT_MULTIVALUED_SEAM')

    def test_point_seam_disagreement_rejected(self):
        h=square()+square(1,1,2,2,z=1,start=2)
        r=ec.preflight(case(support=h))
        self.assertEqual(r['issues'][0]['code'],'SUPPORT_MULTIVALUED_SEAM')

    def test_overhang_host_rejected(self):
        h=square()+square(z=3,start=2)
        r=ec.preflight(case(support=h))
        self.assertEqual(r['status'],'UNVERIFIED')
        self.assertEqual(r['issues'][0]['code'],'SUPPORT_PROJECTED_INTERIOR_OVERLAP')

    def test_coplanar_duplicate_domain_rejected(self):
        r=ec.preflight(case(support=square()+square(start=2)))
        self.assertEqual(r['issues'][0]['code'],'SUPPORT_PROJECTED_INTERIOR_OVERLAP')

    def test_invalid_host_outside_query_is_not_ignored(self):
        h=square()+square(10,10,11,11,start=2)+square(10,10,11,11,z=1,start=4)
        self.assertEqual(ec.preflight(case(support=h))['status'],'UNVERIFIED')

    def test_underside_overlap_is_explicit_facewise_domain(self):
        r=ec.preflight(case(underside=square()+square(z='.1',start=2)))
        self.assertEqual(r['status'],'PASS')
        self.assertEqual(r['coverage']['sum_face_projected_area_m2'],2)
        self.assertEqual(r['maximum']['gap_m'],.1)

    def test_reversed_winding_and_input_order_identical(self):
        a=case()
        b=copy.deepcopy(a)
        for role in ['underside','support']:
            b[role].reverse()
            for t in b[role]:
                t['vertices'].reverse()
        self.assertEqual(ec.preflight(a),ec.preflight(b))

    def test_input_not_mutated(self):
        a=case(); b=copy.deepcopy(a)
        ec.preflight(a)
        self.assertEqual(a,b)

    def test_large_translation_preserves_rational_result(self):
        a=case(square(z='.002'),limits=['-.008','.003'])
        b=copy.deepcopy(a)
        for role in ['support','underside']:
            for t in b[role]:
                for v in t['vertices']:
                    v[0]+=10**12;v[1]-=10**12
        self.assertEqual(ec.preflight(b)['maximum']['gap_m'],ec.preflight(a)['maximum']['gap_m'])

    def test_near_degenerate_projection_configurable_never_skipped(self):
        t=[triangle(0,[(0,0),('1e-8',0),(0,'1e-8')])]
        self.assertEqual(ec.preflight(case(t,t))['status'],'UNVERIFIED')
        self.assertEqual(ec.preflight(case(t,t,tolerances={'min_projected_double_area_m2':'0'}))['status'],'PASS')

    def test_zero_projection_under_and_support(self):
        t=[triangle(0,[(0,0,0),(1,0,0),(1,0,1)])]
        for d in [case(underside=t),case(support=t)]:
            self.assertEqual(ec.preflight(d)['status'],'UNVERIFIED')

    def test_malformed_inputs(self):
        documents=[None,{},case(underside=[]),case(support=[]),case(limits=[1,-1]),
                   case(tolerances={'unknown':0}),case(tolerances={'gap_uncertainty_m':-1})]
        for key,value in [('coordinate_space','OBJECT_LOCAL'),('underside_designation',None),
                          ('support_model','RAYCAST_ENVELOPE')]:
            d=case();d[key]=value;documents.append(d)
        for bad in [float('nan'),float('inf'),True,{},'not a number']:
            d=case();d['underside'][0]['vertices'][0][0]=bad;documents.append(d)
        d=case();d['underside'][1]['id']=0;documents.append(d)
        d=case();d['underside'][0]['vertices'].append([0,1,0]);documents.append(d)
        for d in documents:
            with self.subTest(value=repr(d)[:90]):
                self.assertEqual(ec.preflight(d)['status'],'UNVERIFIED')

    def test_degenerate_support_cannot_turn_empty_query_into_pass(self):
        d=case();d['support'].append(triangle(10,[(20,20),(21,21),(22,22)]))
        self.assertEqual(ec.preflight(d)['status'],'UNVERIFIED')


class IndependentRandomTests(unittest.TestCase):
    def test_100_seeded_integer_cases_against_vertex_edge_oracle(self):
        rng=random.Random(811510)
        for iteration in range(100):
            corners=[(-10,-10,rng.randint(-3,3)),(10,-10,rng.randint(-3,3)),
                     (10,10,rng.randint(-3,3)),(-10,10,rng.randint(-3,3))]
            center=(0,0,rng.randint(-8,8))
            h=[triangle(i,[corners[i],corners[(i+1)%4],center]) for i in range(4)]
            while True:
                points=[(rng.randint(-9,9),rng.randint(-9,9),rng.randint(-4,4)) for _ in range(3)]
                a,b,c=points
                if (b[0]-a[0])*(c[1]-a[1]) != (b[1]-a[1])*(c[0]-a[0]):
                    break
            d=case([triangle(7,points)],h,[-100,100])
            r=ec.preflight(d)
            self.assertEqual(r['status'],'PASS',iteration)
            expected=brute_extrema(d)
            self.assertEqual((F(r['minimum']['exact']['gap_m']),F(r['maximum']['exact']['gap_m'])),expected,iteration)
            if iteration%10==0:
                for role in ['underside','support']:
                    rng.shuffle(d[role])
                    for row in d[role]:
                        row['vertices'].reverse()
                self.assertEqual(r,ec.preflight(d),iteration)


class WorkloadTests(unittest.TestCase):
    def test_triangle_pair_and_vertex_limits_fail_closed(self):
        for key in ['triangles_per_surface','pair_checks','exact_intersections','overlay_vertices']:
            with self.subTest(limit=key), patch.dict(ec.WORK_LIMITS,{key:1}):
                self.assertEqual(ec.preflight(case())['status'],'UNVERIFIED')

    def test_fragment_limit_fails_closed(self):
        with patch.dict(ec.WORK_LIMITS,{'hole_fragments':1}):
            r=ec.preflight(case(square(0,0,2,2)))
            self.assertEqual(r['status'],'UNVERIFIED')

    def test_huge_exponent_and_numeric_string_fail_closed(self):
        for value in ['1e1000000','1e-1000000','1'*129]:
            d=case();d['underside'][0]['vertices'][0][0]=value
            self.assertEqual(ec.preflight(d)['status'],'UNVERIFIED')

    def test_file_byte_limit(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'input.json';p.write_text(json.dumps(case()))
            with patch.dict(ec.WORK_LIMITS,{'input_bytes':1}):
                with self.assertRaises(ec.InvalidInput):
                    ec.load_input(p)


class ActualCaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.input=ec.load_input(ROOT/'fixtures/bank_toe.json')
        cls.result=ec.preflight(cls.input)
        cls.provenance=json.loads((ROOT/'fixtures/bank_toe_provenance.json').read_text())

    def test_actual_bank_toe_exact_failure_and_coverage(self):
        r=self.result
        self.assertEqual((r['status'],r['coverage_status']),('FAIL','PASS'))
        self.assertEqual(r['counts']['underside_triangles'],54)
        self.assertEqual(r['counts']['support_triangles'],1024)
        self.assertAlmostEqual(r['maximum']['gap_m'],.0035964241807012465,places=14)
        self.assertAlmostEqual(r['minimum']['gap_m'],-.007922160710961829,places=14)
        self.assertEqual((r['maximum']['underside_face_id'],r['maximum']['host_face_id']),(121,522))
        self.assertEqual({x['component'] for x in r['faces'] if x['covered_gap_status']=='FAIL'},{'clast_02'})

    def test_actual_sparse_samples_passed_and_candidate_identical(self):
        p=self.provenance
        self.assertTrue(p['candidate_underside_vertices_and_connectivity_identical'])
        self.assertTrue(all(-.008<=lo<=hi<=.003 for lo,hi in p['historical_sparse_sample_ranges_m'].values()))
        self.assertLess(p['historical_sparse_sample_ranges_m']['clast_02'][1],.003)
        self.assertGreater(self.result['maximum']['gap_m'],.003)

    def test_actual_reversed_winding_and_order(self):
        d=copy.deepcopy(self.input)
        for role in ['support','underside']:
            d[role].reverse()
            for t in d[role]:
                t['vertices'].reverse()
        self.assertEqual(self.result,ec.preflight(d))

    def test_archived_report_crosscheck(self):
        from replay_bank_toe import replay
        r=replay()
        self.assertEqual(r['regression_status'],'PASS_REPRODUCED_KNOWN_CONTACT_FAILURE')
        self.assertEqual(r['archive_cross_check']['status'],'PASS')
        self.assertEqual(r['contact_status'],'FAIL')

    def test_bundled_analytic_examples(self):
        for name,status in [('flat_pass','PASS'),('slope_crossing_fail','FAIL'),
                            ('outside_domain_fail','FAIL'),('overhang_unverified','UNVERIFIED'),
                            ('degenerate_unverified','UNVERIFIED')]:
            self.assertEqual(ec.preflight(ec.load_input(ROOT/'fixtures'/(name+'.json')))['status'],status)


class CLITests(unittest.TestCase):
    def invoke(self,path,*args):
        return subprocess.run([sys.executable,str(ROOT/'exact_contact.py'),str(path),*map(str,args)],capture_output=True,text=True)

    def test_cli_codes_json_and_immutable_inputs_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'case.json';out=Path(td)/'report.json'
            src.write_text(json.dumps(case()))
            before=src.read_bytes()
            r=self.invoke(src,'--output',out)
            self.assertEqual(r.returncode,0,r.stderr)
            expected=out.read_bytes()
            r=self.invoke(src,'--output',out)
            self.assertEqual(r.returncode,2)
            self.assertEqual(out.read_bytes(),expected)
            r=self.invoke(src,'--output',src)
            self.assertEqual(r.returncode,2)
            self.assertEqual(src.read_bytes(),before)
            src.write_text(json.dumps(case(square(z=2))))
            self.assertEqual(self.invoke(src).returncode,1)
            src.write_text('{}')
            self.assertEqual(self.invoke(src).returncode,2)

    def test_cli_tolerance_override(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'case.json';p.write_text(json.dumps(case(square(z='.00305'),limits=[-.008,.003])))
            self.assertEqual(self.invoke(p).returncode,1)
            r=self.invoke(p,'--gap-uncertainty-m','.0001')
            self.assertEqual(r.returncode,2)
            self.assertEqual(json.loads(r.stdout)['status'],'UNVERIFIED')

    def test_nonfinite_duplicate_keys_and_broken_json(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'case.json'
            for payload in ['{"a":NaN}', '{"a":1,"a":2}', '{broken']:
                p.write_text(payload)
                r=self.invoke(p)
                self.assertEqual(r.returncode,2)
                self.assertEqual(json.loads(r.stdout)['status'],'UNVERIFIED')

    def test_missing_input(self):
        with tempfile.TemporaryDirectory() as td:
            r=self.invoke(Path(td)/'absent.json')
            self.assertEqual(r.returncode,2)


if __name__=='__main__':
    unittest.main(verbosity=2)
