"""Read-only, stdlib-only triangle-position association. All coordinates are metres.

This is correspondence evidence, not a mesh/export/material/native approval.
UVs, normal/tangent angles, handedness, materials and native checks stay separate.
No rounded key is a validity gate. Exhaustive bounded search avoids bin misses.
"""

from dataclasses import dataclass
from itertools import permutations
from math import isfinite

POSITION_LIMIT_M = 1e-5  # Original strict componentwise limit: error < 10 micrometres.
MAX_TRIANGLES = 4096
MAX_PAIR_CHECKS = 1_000_000
CYCLIC = ((0, 1, 2), (1, 2, 0), (2, 0, 1))
PERMUTATIONS = tuple(permutations(range(3)))


class AssociationError(ValueError):
    """Fail-closed rejection; code is stable for tests and callers."""

    def __init__(self, code, message):
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class TriangleMatch:
    imported_triangle: int
    source_triangle: int
    # source corner index for each imported corner; never reorder either input.
    imported_to_source_corners: tuple
    max_position_component_error_m: float


@dataclass(frozen=True)
class PositionAssociation:
    matches: tuple
    unmatched_source_triangles: tuple
    source_count: int
    imported_count: int
    position_tolerance_m: float
    coverage: str


def _positions(mesh, label):
    if not isinstance(mesh, (list, tuple)) or not 0 < len(mesh) <= MAX_TRIANGLES:
        raise AssociationError("INVALID_INPUT", f"{label} must contain 1..{MAX_TRIANGLES} triangles")
    copied = []
    for ti, triangle in enumerate(mesh):
        if not isinstance(triangle, (list, tuple)) or len(triangle) != 3:
            raise AssociationError("INVALID_INPUT", f"{label} triangle {ti} needs three corners")
        points = []
        for ci, point in enumerate(triangle):
            if not isinstance(point, (list, tuple)) or len(point) != 3:
                raise AssociationError("INVALID_INPUT", f"{label} triangle {ti} corner {ci} needs XYZ")
            coords = []
            for value in point:
                if type(value) not in (int, float):
                    raise AssociationError("INVALID_INPUT", f"{label} coordinates must be finite numbers")
                try:
                    coordinate = float(value)
                except OverflowError as exc:
                    raise AssociationError("INVALID_INPUT", f"{label} coordinate overflows binary64") from exc
                if not isfinite(coordinate):
                    raise AssociationError("NONFINITE_INPUT", f"{label} triangle {ti} corner {ci}")
                coords.append(coordinate)
            points.append(tuple(coords))
        copied.append(tuple(points))
    return tuple(copied)


def associate_triangle_positions(
    source_triangles_m,
    imported_triangles_m,
    *,
    position_tolerance_m=POSITION_LIMIT_M,
    require_full_coverage=True,
):
    """Return a unique, winding-preserving, one-to-one position association.

    Inputs: finite XYZ triangles in the SAME coordinate frame, measured in metres.
    The metric is maximum absolute coordinate-component error, not Euclidean
    distance. Every component must be STRICTLY below position_tolerance_m.
    Equality fails; no epsilon padding is added. The original 1e-5 m limit may
    be tightened, never widened. Triangle order and cyclic corner order may vary.

    All six corner permutations are inspected to detect ambiguity before the
    unique match is required to be cyclic. Reversed winding is rejected.
    Multiple locally valid source triangles/corner maps fail even when a global
    solver or UVs could choose one. Already-used sources are NOT hidden from
    later searches. Global duplicate assignments fail after local matching.

    Full source coverage is required by default. Explicit False permits a
    diagnostic subset injection only; uncovered sources are returned. A partial
    replay must not be presented as a complete mesh pass.

    Work is capped at 4096 triangles per input and 1,000,000 triangle pairs,
    each with at most six permutations of nine components. No spatial hash is
    needed; a future accelerator must preserve this complete candidate set.
    No input writes, exporter calls, external dependencies or file I/O.
    """
    if (type(position_tolerance_m) not in (int, float)
            or not 0 < position_tolerance_m <= POSITION_LIMIT_M):
        raise AssociationError("INVALID_TOLERANCE", "require 0 < tolerance <= 1e-5 metres")
    if type(require_full_coverage) is not bool:
        raise AssociationError("INVALID_INPUT", "require_full_coverage must be boolean")
    source = _positions(source_triangles_m, "source")
    imported = _positions(imported_triangles_m, "imported")
    if require_full_coverage and len(source) != len(imported):
        raise AssociationError("COUNT_MISMATCH", "complete association needs equal triangle counts")
    if len(source) * len(imported) > MAX_PAIR_CHECKS:
        raise AssociationError("WORKLOAD_LIMIT", f"more than {MAX_PAIR_CHECKS} triangle pairs")

    matches = []
    for di, destination in enumerate(imported):
        chosen = None
        for si, candidate in enumerate(source):
            valid = []
            for permutation in PERMUTATIONS:
                maximum = 0.0
                for ci, source_ci in enumerate(permutation):
                    error = max(abs(destination[ci][axis] - candidate[source_ci][axis]) for axis in range(3))
                    if error >= position_tolerance_m:
                        break
                    maximum = max(maximum, error)
                else:
                    valid.append((permutation, maximum))
            if len(valid) > 1:
                raise AssociationError("AMBIGUOUS_CORNERS", f"imported {di}, source {si}: multiple corner maps")
            if valid:
                if chosen is not None:
                    raise AssociationError("AMBIGUOUS_TRIANGLE", f"imported {di}: sources {chosen.source_triangle} and {si}")
                chosen = TriangleMatch(di, si, valid[0][0], valid[0][1])
        if chosen is None:
            raise AssociationError("NO_MATCH", f"imported triangle {di}: no source within strict tolerance")
        if chosen.imported_to_source_corners not in CYCLIC:
            raise AssociationError("REVERSED_WINDING", f"imported {di}, source {chosen.source_triangle}")
        matches.append(chosen)

    used = {}
    for match in matches:
        si = match.source_triangle
        if si in used:
            raise AssociationError("DUPLICATE_ASSIGNMENT", f"imported {used[si]} and {match.imported_triangle} both map to source {si}")
        used[si] = match.imported_triangle
    unmatched = tuple(si for si in range(len(source)) if si not in used)
    if require_full_coverage and unmatched:
        raise AssociationError("INCOMPLETE_COVERAGE", "some source triangles are unused")
    return PositionAssociation(tuple(matches), unmatched, len(source), len(imported),
                               float(position_tolerance_m), "PARTIAL" if unmatched else "COMPLETE")
