"""Analytic and hostile-input regression tests; no third-party packages or input packs needed."""
import copy
import io
import json
from pathlib import Path
import stat
import struct
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile
import zlib
import texture_budget as t


def chunk(kind,body):
    return struct.pack('>I',len(body))+kind+body+struct.pack('>I',zlib.crc32(kind+body)&0xffffffff)


def png(w=4,h=4,ctype=2,depth=8,extra=b'',raw=None,interlace=0):
    channels={0:1,2:3,3:1,4:2,6:4}[ctype]
    header=struct.pack('>IIBBBBB',w,h,depth,ctype,0,0,interlace)
    if raw is None:
        raw=(b'\0'+b'\x7f'*((w*channels*depth+7)//8))*h
    palette=chunk(b'PLTE',b'\0\0\0\xff\xff\xff') if ctype==3 else b''
    return t.PNG_SIGNATURE+chunk(b'IHDR',header)+palette+extra+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')


def glb(image=None,changes=None):
    image=png() if image is None else image
    j={'asset':{'version':'2.0'},'buffers':[{'byteLength':len(image)}],
       'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':len(image)}],
       'images':[{'bufferView':0,'mimeType':'image/png','name':'BaseColor'}],
       'textures':[{'source':0}], 'materials':[{'name':'Test','pbrMetallicRoughness':{'baseColorTexture':{'index':0}}}],
       'meshes':[{'primitives':[{'material':0}]}]}
    if changes:
        changes(j)
    jraw=json.dumps(j).encode(); jraw+=b' '*((-len(jraw))%4)
    binary=image+b'\0'*((-len(image))%4)
    body=struct.pack('<II',len(jraw),0x4e4f534a)+jraw+struct.pack('<II',len(binary),0x004e4942)+binary
    return struct.pack('<4sII',b'glTF',2,12+len(body))+body


def zip_path(root,name,entries):
    p=root/name
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,raw in entries:
            z.writestr(name,raw)
    return p


class AllocationTests(unittest.TestCase):
    def test_one_pixel(self):
        for fmt,n in [('RGBA8',4),('BC1',8),('BC5',16),('BC7',16)]:
            self.assertEqual(t.allocation(1,1,fmt)['full_mip_bytes'],n)

    def test_smaller_than_block(self):
        self.assertEqual(t.mip_dimensions(3,2),[(3,2),(1,1)])
        self.assertEqual(t.allocation(3,2,'RGBA8')['full_mip_bytes'],28)
        self.assertEqual(t.allocation(3,2,'BC1')['full_mip_bytes'],16)
        self.assertEqual(t.allocation(3,2,'BC5')['full_mip_bytes'],32)

    def test_non_power_of_two(self):
        self.assertEqual(t.mip_dimensions(7,5),[(7,5),(3,2),(1,1)])
        self.assertEqual(t.allocation(7,5,'RGBA8')['full_mip_bytes'],168)
        self.assertEqual(t.allocation(7,5,'BC1')['full_mip_bytes'],48)
        self.assertEqual(t.allocation(7,5,'BC7')['full_mip_bytes'],96)

    def test_narrow_chain(self):
        self.assertEqual(t.mip_dimensions(1,9),[(1,9),(1,4),(1,2),(1,1)])
        self.assertEqual(t.allocation(1,9,'BC1')['full_mip_bytes'],48)

    def test_1024_analytic(self):
        self.assertEqual(t.allocation(1024,1024,'RGBA8')['full_mip_bytes'],5592404)
        self.assertEqual(t.allocation(1024,1024,'BC1')['full_mip_bytes'],699064)
        self.assertEqual(t.allocation(1024,1024,'BC7')['full_mip_bytes'],1398128)
        self.assertEqual(len(t.allocation(1024,1024,'BC7')['levels']),11)

    def test_invalid_dimensions(self):
        for w,h in [(0,1),(-1,2),(True,2),(1,0)]:
            with self.assertRaises(t.Invalid): t.mip_dimensions(w,h)


class PNGTests(unittest.TestCase):
    def test_rgb_and_gray_not_rgba(self):
        self.assertEqual(t.png_info(png())['stored_channels'],3)
        info=t.png_info(png(7,5,0))
        self.assertEqual(info['stored_channels'],1)
        self.assertEqual(info['native_channel_raster_bytes'],35)

    def test_gray_1bit_packed_rows(self):
        self.assertEqual(t.png_info(png(7,5,0,1))['native_channel_raster_bytes'],5)

    def test_rgba(self):
        self.assertTrue(t.png_info(png(4,4,6))['has_alpha_channel'])

    def test_transparency(self):
        self.assertTrue(t.png_info(png(extra=chunk(b'tRNS',b'\0'*6)))['has_transparency_metadata'])

    def test_indexed(self):
        self.assertEqual(t.png_info(png(4,4,3))['channel_layout'],'Indexed')

    def test_interlaced_one_pixel(self):
        self.assertEqual(t.png_info(png(1,1,2,raw=b'\0\1\2\3',interlace=1))['validated_filtered_scanline_bytes'],4)

    def test_bad_crc(self):
        data=bytearray(png()); data[20]^=1
        with self.assertRaises(t.Invalid): t.png_info(bytes(data))

    def test_truncated(self):
        for data in [b'',png()[:10],png()[:-1]]:
            with self.assertRaises(t.Invalid): t.png_info(data)

    def test_trailing_data(self):
        with self.assertRaises(t.Invalid): t.png_info(png()+b'evil')

    def test_duplicate_ihdr(self):
        data=png()
        with self.assertRaises(t.Invalid): t.png_info(data[:33]+data[8:33]+data[33:])

    def test_zero_dimensions(self):
        with self.assertRaises(t.Invalid): t.png_info(png(0,4))

    def test_filter(self):
        with self.assertRaises(t.Invalid): t.png_info(png(1,1,raw=b'\5\0\0\0'))

    def test_decompressed_under_overrun(self):
        for raw in [b'\0',b'\0'*5000]:
            with self.assertRaises(t.Invalid): t.png_info(png(raw=raw))

    def test_decompressed_budget(self):
        with patch.dict(t.LIMITS,png_scanline_bytes=10):
            with self.assertRaises(t.Invalid): t.png_info(png())

    def test_unknown_critical(self):
        with self.assertRaises(t.Invalid): t.png_info(png(extra=chunk(b'ABCD',b'')))

    def test_animation_rejected(self):
        with self.assertRaises(t.Invalid): t.png_info(png(extra=chunk(b'acTL',struct.pack('>II',1,0))))

    def test_zlib_garbage(self):
        data=t.PNG_SIGNATURE+chunk(b'IHDR',struct.pack('>IIBBBBB',1,1,8,2,0,0,0))+chunk(b'IDAT',b'junk')+chunk(b'IEND',b'')
        with self.assertRaises(t.Invalid): t.png_info(data)


class GLBTests(unittest.TestCase):
    def test_valid_embedded_image_and_usage(self):
        image=png()
        imgs,meta=t.glb_images(glb(image))
        self.assertEqual(imgs[0][2],image)
        self.assertTrue(imgs[0][3][0]['referenced_by_mesh_primitive'])
        self.assertEqual(t.role_for(imgs[0][1],imgs[0][3])[0],'base_color')
        self.assertFalse(meta['unresolved'])

    def test_wrong_header(self):
        with self.assertRaises(t.Invalid): t.parse_glb(b'NOPE'+glb()[4:])

    def test_total_length(self):
        with self.assertRaises(t.Invalid): t.parse_glb(glb()+b'\0')

    def test_chunk_bounds(self):
        data=bytearray(glb());struct.pack_into('<I',data,12,len(data)+4)
        with self.assertRaises(t.Invalid): t.parse_glb(bytes(data))

    def test_chunk_alignment(self):
        data=bytearray(glb());struct.pack_into('<I',data,12,7)
        with self.assertRaises(t.Invalid): t.parse_glb(bytes(data))

    def test_buffer_view_bounds(self):
        with self.assertRaises(t.Invalid):
            t.glb_images(glb(changes=lambda j:j['bufferViews'][0].update(byteOffset=1)))

    def test_negative_buffer_view(self):
        with self.assertRaises(t.Invalid):
            t.glb_images(glb(changes=lambda j:j['bufferViews'][0].update(byteOffset=-1)))

    def test_invalid_material_reference(self):
        with self.assertRaises(t.Invalid):
            t.glb_images(glb(changes=lambda j:j['meshes'][0]['primitives'][0].update(material=9)))

    def test_invalid_texture_reference(self):
        with self.assertRaises(t.Invalid):
            t.glb_images(glb(changes=lambda j:j['textures'][0].update(source=9)))

    def test_external_uri_unresolved_not_fetched(self):
        imgs,meta=t.glb_images(glb(changes=lambda j:j.update(images=[{'uri':'https://example.invalid/a.png'}])))
        self.assertFalse(imgs); self.assertTrue(meta['unresolved'])

    def test_alternate_texture_source_disclosed(self):
        imgs,meta=t.glb_images(glb(changes=lambda j:j['textures'][0].update(extensions={'EXT_texture_webp':{'source':0}})))
        self.assertTrue(meta['unresolved'])

    def test_buffer_length_beyond_bin(self):
        with self.assertRaises(t.Invalid):
            t.glb_images(glb(changes=lambda j:j['buffers'][0].update(byteLength=999999)))

    def test_unused_image_not_marked_resident(self):
        imgs,meta=t.glb_images(glb(changes=lambda j:j.update(meshes=[])))
        self.assertFalse(imgs[0][3][0]['referenced_by_mesh_primitive'])


class ArchiveAndDedupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()

    def test_duplicate_across_archives_and_embedded(self):
        image=png()
        a=zip_path(self.root,'a.zip',[('a/textures/BaseColor.png',image),('a/exports/a.glb',glb(image)),('a/previews/proof.png',image)])
        b=zip_path(self.root,'b.zip',[('b/textures/BaseColor.png',image)])
        report=t.inspect([a,b])
        self.assertEqual(report['counts']['source_texture_files'],2)
        self.assertEqual(report['counts']['exact_unique_source_plus_glb'],1)
        self.assertEqual(report['counts']['proof_previews'],1)
        self.assertEqual(report['scenarios']['source_plus_glb_packaging_union_separate_per_occurrence']['image_resources_assumed'],3)
        self.assertEqual(len(report['byte_identity_groups']),1)

    def test_same_pixels_different_encoding_not_deduped(self):
        a=zip_path(self.root,'a.zip',[('a/textures/BaseColor.png',png()),('a/textures/BaseColor2.png',png(extra=chunk(b'tEXt',b'Label\0same pixels')))])
        report=t.inspect([a])
        self.assertEqual(report['counts']['exact_unique_source_textures'],2)

    def test_hash_collision_still_requires_bytes(self):
        rows=[{'id':'a','encoded_sha256':'collision','encoded_bytes':1},{'id':'b','encoded_sha256':'collision','encoded_bytes':1}]
        self.assertEqual(len(t.group_exact(rows,{'a':b'a','b':b'b'})),2)

    def test_zip_slip_absolute_backslash_drive(self):
        for n in ['../evil.py','/evil.py','a/../../evil.py','a\\evil.py','C:/evil.py','a//evil.py']:
            with self.subTest(n=n):
                p=zip_path(self.root,'bad.zip',[(n,b'not executed')])
                with self.assertRaises(t.Invalid): t.inspect([p])

    def test_symlink_refused(self):
        i=zipfile.ZipInfo('link');i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16
        p=zip_path(self.root,'link.zip',[(i,b'../target')])
        with self.assertRaises(t.Invalid): t.inspect([p])

    def test_duplicate_zip_member(self):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            p=zip_path(self.root,'dup.zip',[('x',b'1'),('x',b'2')])
        with self.assertRaises(t.Invalid): t.inspect([p])

    def test_member_and_archive_size_limits(self):
        p=zip_path(self.root,'a.zip',[('x',b'x'*100)])
        with patch.dict(t.LIMITS,member_bytes=10):
            with self.assertRaises(t.Invalid): t.inspect([p])
        with patch.dict(t.LIMITS,archive_bytes=10):
            with self.assertRaises(t.Invalid): t.inspect([p])

    def test_member_count_and_total_limits(self):
        p=zip_path(self.root,'a.zip',[('x',b'x'*100),('y',b'x'*100)])
        with patch.dict(t.LIMITS,members=1):
            with self.assertRaises(t.Invalid): t.inspect([p])
        with patch.dict(t.LIMITS,total_uncompressed_bytes=150):
            with self.assertRaises(t.Invalid): t.inspect([p])

    def test_hash_baseline_and_input_unchanged(self):
        p=zip_path(self.root,'a.zip',[('a/textures/BaseColor.png',png())]);before=p.read_bytes()
        manifest={'inputs':[{'filename':'a.zip','sha256':t.sha(before),'bytes':len(before),'asset_status':'CONTACT_HELD'}]}
        r=t.inspect([p],manifest)
        self.assertTrue(r['inputs'][0]['baseline_verified']);self.assertEqual(p.read_bytes(),before)
        manifest['inputs'][0]['sha256']='wrong'
        with self.assertRaises(t.Invalid): t.inspect([p],manifest)

    def test_report_creation_and_no_overwrite(self):
        p=zip_path(self.root,'a.zip',[('a/textures/BaseColor.png',png())]);r=t.inspect([p]);out=self.root/'out'
        t.write_report(r,out)
        self.assertEqual({p.name for p in out.iterdir()},{'report.json','report.md','images.csv','scenarios.csv'})
        self.assertEqual(json.loads((out/'report.json').read_text())['counts'],r['counts'])
        with self.assertRaises(t.Invalid): t.write_report(r,out)

    def test_no_executable_extraction(self):
        p=zip_path(self.root,'a.zip',[('evil.py',b'raise Exception("never execute")'),('a/textures/BaseColor.png',png())])
        t.inspect([p]);self.assertFalse((self.root/'evil.py').exists())

    def test_unsupported_image_partial_coverage(self):
        p=zip_path(self.root,'a.zip',[('textures/not_png.jpg',b'not decoded')])
        r=t.inspect([p]);self.assertFalse(r['inventory_complete_for_supported_scope'])

    def test_cli_partial_exit_three(self):
        p=zip_path(self.root,'a.zip',[('textures/image.jpg',b'jpeg')])
        with patch('sys.stdout',new=io.StringIO()):
            self.assertEqual(t.main([str(p),'--out',str(self.root/'out')]),3)

    def test_json_duplicate_and_nonfinite(self):
        for raw in [b'{"a":1,"a":2}',b'{"a":NaN}']:
            with self.assertRaises(t.Invalid): t.json_data(raw)

if __name__=='__main__':
    unittest.main(verbosity=2)
