"""Read-only CLI: replay recorded imported-position witnesses, not a new FBX import."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from triangle_association import AssociationError, POSITION_LIMIT_M, associate_triangle_positions

MAX_JSON_BYTES = 4 * 1024 * 1024


class ReplayError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ReplayError(message)


def read_json(path):
    with Path(path).open("rb") as handle:
        raw = handle.read(MAX_JSON_BYTES + 1)
    require(len(raw) <= MAX_JSON_BYTES, "JSON workload limit exceeded")
    return json.loads(raw)


def rounded_key(points):
    """Legacy five-decimal key: demonstration only, NEVER a matching gate."""
    return tuple(sorted(tuple(round(float(x), 5) for x in p) for p in points))


def hash_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_original_hashes(root, records):
    root = Path(root).resolve()
    require(0 < len(records) <= 16, "original-file manifest count is outside bounds")
    require(all(type(r["bytes"]) is int and 0 <= r["bytes"] <= 64 * 1024 * 1024
                for r in records.values()), "original-file byte workload limit exceeded")
    checked = {}
    for relative, expected in records.items():
        require(not Path(relative).is_absolute(), "original paths must be relative")
        path = (root / relative).resolve()
        require(path.is_relative_to(root), "original path escapes the supplied root")
        require(path.is_file(), f"original file is missing: {relative}")
        require(path.stat().st_size == expected["bytes"], f"original size differs: {relative}")
        actual = hash_file(path)
        require(actual == expected["sha256"], f"original SHA-256 differs: {relative}")
        checked[relative] = actual
    return checked


def verify_fixture_projection(fixture, root):
    """Verify bundled numbers against saved evidence when originals are available."""
    root = Path(root)
    snapshot = read_json(root / "inputs/MATERIAL_FRESH_CORNER_SNAPSHOT.json")
    diagnostic = read_json(root / "evidence/FBX_READONLY_STRICT_DIAGNOSTIC_GATE.json")
    associations = read_json(root / "evidence/FBX_READONLY_STRICT_CORNER_ASSOCIATIONS.json")
    projected = [{"id": t["index"], "positions": [c["position"] for c in t["corners"]],
                  "loops": [c["loop"] for c in t["corners"]],
                  "vertices": [c["vertex"] for c in t["corners"]]} for t in snapshot["triangles"]]
    require(fixture["source_triangles"] == projected, "source fixture differs from original snapshot")
    require(fixture["source_coordinate_space"] == snapshot["coordinate_space"]
            and fixture["source_matrix_world"] == snapshot["matrix_world"], "source frame metadata differs")
    historical = {k: v for k, v in diagnostic.items() if k not in ("lookup_misses", "material_summary")}
    require(fixture["recorded_full_gate"] == historical, "historical gate differs from original evidence")
    raw_witnesses = [{k: v for k, v in w.items() if k != "recorded_corner_associations"}
                     for w in fixture["witnesses"]]
    require(raw_witnesses == diagnostic["lookup_misses"], "witness fixture differs from original diagnostic")
    for witness in fixture["witnesses"]:
        rows = [r for r in associations["associations"] if r["export_triangle"] == witness["export_triangle"]]
        require(rows == witness["recorded_corner_associations"], "corner records differ from original evidence")


def replay(fixture, original_root=None):
    require(fixture["schema"] == "yourquest_triangle_position_witnesses_v1", "unsupported fixture schema")
    require(fixture["units"] == "metres" and fixture["position_limit_m"] == POSITION_LIMIT_M,
            "fixture must retain original metre-based tolerance")
    require(fixture["position_boundary"] == "strict_less_than", "original limit is exclusive")
    source = fixture["source_triangles"]
    witnesses = fixture["witnesses"]
    require(len(source) == 884 and len(witnesses) == 22, "this replay requires the exact saved 884/22 case")
    require(len({t["id"] for t in source}) == len(source), "duplicate source triangle IDs")
    require(len({w["export_triangle"] for w in witnesses}) == len(witnesses), "duplicate witness IDs")
    before = None
    if original_root is not None:
        before = verify_original_hashes(original_root, fixture["original_files"])
        verify_fixture_projection(fixture, original_root)
    result = associate_triangle_positions([t["positions"] for t in source],
                                          [w["imported_positions"] for w in witnesses],
                                          require_full_coverage=False)
    rows = []
    for match, witness in zip(result.matches, witnesses):
        triangle = source[match.source_triangle]
        require(triangle["id"] == witness["source_triangle"], "association differs from saved source ID")
        require(triangle["positions"] == witness["source_positions"], "source witness differs from snapshot")
        require(witness["unchanged_position_limit_m"] == POSITION_LIMIT_M, "witness threshold changed")
        require(match.max_position_component_error_m == witness["max_position_component_error_m"],
                "witness position error differs")
        require(rounded_key(witness["imported_positions"]) != rounded_key(triangle["positions"]),
                "saved witness no longer reproduces the old rounded-key miss")
        corner_rows = witness["recorded_corner_associations"]
        require(len(corner_rows) == 3, "witness needs three recorded corner associations")
        for ci, source_ci in enumerate(match.imported_to_source_corners):
            row = corner_rows[ci]
            require(row["export_triangle"] == witness["export_triangle"]
                    and row["source_triangle"] == triangle["id"]
                    and row["source_loop"] == triangle["loops"][source_ci]
                    and row["source_vertex"] == triangle["vertices"][source_ci],
                    "position correspondence disagrees with saved corner mapping")
        rows.append({"imported_triangle": witness["export_triangle"], "source_triangle": triangle["id"],
                     "imported_to_source_corners": match.imported_to_source_corners,
                     "max_position_component_error_m": match.max_position_component_error_m,
                     "legacy_rounded_key_missed": True})
    after = verify_original_hashes(original_root, fixture["original_files"]) if before is not None else None
    require(before == after, "original files changed during replay")
    return {
        "status": "PASS_RECORDED_POSITION_WITNESSES_ONLY",
        "coverage": result.coverage,
        "actual_imported_triangles_replayed": len(result.matches),
        "source_candidates_checked_per_witness": len(source),
        "unreplayed_source_triangles": len(result.unmatched_source_triangles),
        "position_limit_m": POSITION_LIMIT_M,
        "position_boundary": "strict_less_than; equality rejected",
        "maximum_replayed_error_m": max(m.max_position_component_error_m for m in result.matches),
        "winding": "all unique mappings are cyclic",
        "global_assignment": "one-to-one injection; not a complete-mesh replay",
        "original_files_verified_unchanged": before is not None,
        "original_sha256": before,
        "fixture_projection_verified_against_originals": before is not None,
        "independent_gates_this_run": {k: "NOT_RUN" for k in
                                       ("uv", "normal", "tangent", "handedness", "material", "native")},
        "historical_full_gate_only": fixture["recorded_full_gate"],
        "associations": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, default=Path(__file__).with_name("recorded_case.json"))
    parser.add_argument("--original-root", type=Path,
                        help="optional original closure folder; verify eight input hashes before/after")
    args = parser.parse_args()
    try:
        report = replay(read_json(args.fixture), args.original_root)
    except (AssociationError, ReplayError, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "HOLD_REPLAY", "error": str(exc)}))
        return 1
    print(json.dumps(report, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
