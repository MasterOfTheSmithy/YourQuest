#!/usr/bin/env python3
"""One-time read-only extraction from immutable evidence; never opens Blender."""
import argparse
import hashlib
import json
from pathlib import Path

IDENTITY = [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]]
FILES = {
    'host': 'input_host/HOST_SOURCE_CORNERS.json',
    'control': 'inputs/control_gray/sidecar.json',
    'candidate': 'evidence/FRESH_GRAY_SIDECAR.json',
    'placement': 'inputs/control_gray/placement.json',
    'recipe': 'inputs/FROZEN_CANDIDATE_GEOMETRY.json',
    'diagnosis': 'evidence/EXACT_CONTACT_HOLD_DIAGNOSIS.json',
    'verifier': 'source/verify_contact_held.py',
    'sparse_verifier': 'inputs/control_gray/build_shape.py',
    'offline_diagnosis': 'source/diagnose_contact_hold_offline.py',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(root, out):
    before = {name: sha(root/rel) for name, rel in FILES.items()}
    data = {name: json.loads((root/rel).read_text()) for name, rel in FILES.items() if rel.endswith('.json')}
    for role, key in [('control', 'control_sidecar'), ('candidate', 'candidate_fresh_sidecar'), ('host', 'actual_host_sidecar')]:
        if before[role] != data['diagnosis']['source_sha256'][key]:
            raise ValueError(f'Immutable diagnosis hash mismatch: {role}')
    for role in ['control', 'candidate']:
        if data[role]['coordinate_space'] != 'BLENDER_OBJECT_LOCAL_RAW_MESH' or data[role]['matrix_world'] != IDENTITY:
            raise ValueError(f'Unproven world-space identity transform: {role}')
    placement = data['placement']
    if not placement['host_transform_identity'] or placement['units'] != 'metres' or placement['up'] != 'source Z':
        raise ValueError('Host world-space/unit declaration is not the pinned identity case')
    host = data['host']
    if len(host['corners']) % 3:
        raise ValueError('Host corners are not a triangle stream')
    support = [{'id': i//3, 'vertices': [host['vertices'][c['vertex']] for c in host['corners'][i:i+3]]}
               for i in range(0, len(host['corners']), 3)]
    underside, identity_records = [], []
    base = 0
    for part, candidate_part in zip(placement['parts'], data['recipe']['parts'], strict=True):
        if part['id'] != candidate_part['id']:
            raise ValueError('Part order mismatch')
        count = {'coarse': 8, 'medium': 6, 'fine': 4}[part['grade']]
        new_base = candidate_part['vertex_offset']
        if count != candidate_part['bottom_vertex_count']:
            raise ValueError('Bottom designation count mismatch')
        a = data['control']['vertices'][base:base+count]
        b = data['candidate']['vertices'][new_base:new_base+count]
        if a != b:
            raise ValueError('Candidate underside vertices differ')
        old_faces = [(i, p['vertices']) for i, p in enumerate(data['control']['polygons'])
                     if all(base <= v < base+count for v in p['vertices'])]
        new_faces = [(i, p['vertices']) for i, p in enumerate(data['candidate']['polygons'])
                     if all(new_base <= v < new_base+count for v in p['vertices'])]
        old_local = [[v-base for v in f] for _, f in old_faces]
        new_local = [[v-new_base for v in f] for _, f in new_faces]
        if old_local != new_local or new_local != candidate_part['bottom_faces']:
            raise ValueError('Candidate underside connectivity differs')
        for (fi, f), (nfi, _) in zip(old_faces, new_faces, strict=True):
            underside.append({'id': fi, 'component': part['id'], 'vertices': [data['control']['vertices'][v] for v in f]})
            identity_records.append({'control_face_id': fi, 'candidate_face_id': nfi, 'component': part['id']})
        base += part['vertices']
    doc = {'schema': 'yq_exact_contact_input_v1', 'coordinate_space': 'WORLD_XYZ_METRES',
           'underside_designation': 'EXPLICIT_TRIANGLES',
           'support_model': 'SINGLE_VALUED_TRIANGULATED_HEIGHTFIELD', 'gap_limits_m': [-0.008, 0.003],
           'tolerances': {'min_projected_double_area_m2': '1e-14', 'gap_uncertainty_m': '0', 'coverage_uncertainty_m2': '0'},
           'underside': underside, 'support': support}
    provenance = {'schema': 'yq_bank_toe_exact_contact_provenance_v1',
                  'selection': 'Control first 8/6/4 bottom-ring vertices by coarse/medium/fine grade and faces entirely in that explicitly authored ring; candidate independently checked against frozen bottom_faces and bottom_vertex_count.',
                  'coordinate_evidence': 'Both captured object matrix_world values equal identity. Pinned placement declares identity host, metres and source Z up. Historical Blender verifier checked host sidecar against actual source; this run does not reopen Blender.',
                  'source_files': {name: {'relative_path': rel, 'sha256': before[name]} for name, rel in FILES.items()},
                  'candidate_underside_vertices_and_connectivity_identical': True,
                  'candidate_face_mapping': identity_records,
                  'historical_sparse_sample_ranges_m': {p['id']: p['bottom_triangle_sample_gap_range_m'] for p in placement['parts']},
                  'historical_exact_global_range_m': [min(r['bottom_gap_range_m'][0] for r in data['diagnosis']['rows']['control']), max(r['bottom_gap_range_m'][1] for r in data['diagnosis']['rows']['control'])],
                  'historical_max_witness': next(r['bottom_max_witness'] for r in data['diagnosis']['rows']['control'] if r['id'] == 'clast_02'),
                  'assets_mutated': False, 'blender_run': False, 'native': 'NOT_RUN'}
    if before != {name: sha(root/rel) for name, rel in FILES.items()}:
        raise ValueError('Evidence changed while reading')
    out.mkdir(parents=True, exist_ok=True)
    for name, value in [('bank_toe.json', doc), ('bank_toe_provenance.json', provenance)]:
        with (out/name).open('x') as f:
            json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
            f.write('\n')
    print(json.dumps({'underside_triangles': len(underside), 'host_triangles': len(support), 'immutable_inputs_unchanged': True, 'candidate_identical': True}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_root', type=Path)
    parser.add_argument('output_directory', type=Path)
    args = parser.parse_args()
    extract(args.evidence_root, args.output_directory)
