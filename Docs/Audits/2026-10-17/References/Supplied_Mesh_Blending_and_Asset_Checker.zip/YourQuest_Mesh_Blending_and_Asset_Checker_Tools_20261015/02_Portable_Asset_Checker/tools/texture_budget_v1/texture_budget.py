#!/usr/bin/env python3
"""Read-only ZIP/PNG/GLB texture inventory and hypothetical payload ledger. Stdlib only."""
import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import struct
import sys
import zipfile
import zlib

VERSION = '1.0'
MIB = 1024 * 1024
LIMITS = dict(archives=16, archive_bytes=256*MIB, members=4096,
              member_bytes=64*MIB, total_uncompressed_bytes=512*MIB,
              png_scanline_bytes=128*MIB, dimension=16384, images=1024, json_bytes=4*MIB)
PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
FORMATS = {'RGBA8': None, 'BC1': 8, 'BC5': 16, 'BC7': 16}
SOURCES = [
    'https://learn.microsoft.com/en-us/windows/win32/direct3d11/texture-block-compression-in-direct3d-11',
    'https://registry.khronos.org/DataFormat/specs/1.4/dataformat.1.4.html',
    'https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html',
    'https://www.w3.org/TR/png-3/']
CAUTIONS = [
    'No Unity import, player, profiler, GPU, or Blender was run. No VRAM/performance or art/contact approval.',
    'The user reported an 8 GB VRAM-class device. That is not a free-memory budget; no availability or utilization is inferred.',
    'PNG encoded bytes, native-channel raster-size arithmetic, and assumed GPU-format payload bytes are different quantities.',
    'Exact deduplication requires SHA-256 AND byte-for-byte equality. Differently encoded images remain separate even if their pixels might match.',
    'Byte identity is a lower-bound shared-resource opportunity, not proof of importer sharing. Different settings, color spaces, samplers, containers, or asset GUIDs can create separate resources.',
    'All budget rows are tight 2D texture-data payload scenarios with full mip chains; no API/driver alignment, metadata, staging, CPU copies, streaming, render targets, geometry, or other allocations are included.',
    'BC rows are representation-size calculations, not a compression or quality test. Device/API support, source semantics, normal convention, import settings, resizing and quality require native validation.',
    'Preview/evidence PNGs are inventoried separately and excluded from material totals. Source+GLB union is a packaging superset, not a statement that both representations load together.',
    'Source receipts are historical assertions, not a fresh .blend inspection. Only stated receipt hashes/dimensions and source file hashes are compared to current archive bytes.',
    'Unsupported image types and URI-backed GLB images are reported as unresolved. This is a bounded inventory, not a complete PNG or glTF conformance validator.'
]

class Invalid(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise Invalid(message)


def uint(x, name):
    need(type(x) is int and x >= 0, 'Invalid nonnegative integer: ' + name)
    return x


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    need(isinstance(name, str) and name and '\\' not in name and '\x00' not in name,
         'Unsafe ZIP member name')
    p = PurePosixPath(name)
    need(not p.is_absolute() and all(x not in ('..', '.') for x in name.rstrip('/').split('/'))
         and all(':' not in x and x for x in name.rstrip('/').split('/')),
         'Unsafe ZIP member path: ' + repr(name))
    return name


def mip_dimensions(w, h):
    need(type(w) is int and type(h) is int and w > 0 and h > 0, 'Invalid dimensions')
    result = []
    while True:
        result.append((w, h))
        if w == 1 and h == 1:
            return result
        w, h = max(1, w // 2), max(1, h // 2)


def allocation(w, h, fmt):
    need(fmt in FORMATS, 'Unknown format')
    per_level = []
    for mw, mh in mip_dimensions(w, h):
        n = mw*mh*4 if fmt == 'RGBA8' else ((mw+3)//4)*((mh+3)//4)*FORMATS[fmt]
        per_level.append({'width': mw, 'height': mh, 'bytes': n})
    return {'base_bytes': per_level[0]['bytes'], 'full_mip_bytes': sum(x['bytes'] for x in per_level),
            'levels': per_level}


def png_info(data):
    """Validate bounds/CRCs/scanline sizes; do not canonicalize or compare pixels."""
    need(len(data) <= LIMITS['member_bytes'] and data.startswith(PNG_SIGNATURE), 'Invalid PNG signature/size')
    pos, chunks, idat = 8, [], []
    info = None
    palette = None
    trns = False
    idat_ended = False
    while pos < len(data):
        need(pos+12 <= len(data), 'Truncated PNG chunk')
        size, kind = struct.unpack_from('>I4s', data, pos)
        need(size <= LIMITS['member_bytes'] and pos+size+12 <= len(data), 'PNG chunk out of bounds')
        body = data[pos+8:pos+8+size]
        need(zlib.crc32(kind+body) & 0xffffffff == struct.unpack_from('>I', data, pos+8+size)[0],
             'PNG CRC mismatch')
        need(all(65 <= c <= 90 or 97 <= c <= 122 for c in kind) and not (kind[2] & 32), 'Invalid PNG chunk type')
        if not chunks:
            need(kind == b'IHDR', 'PNG IHDR must be first')
        if kind == b'IHDR':
            need(not chunks and size == 13, 'Invalid/duplicate PNG IHDR')
            w,h,depth,ctype,comp,filt,interlace = struct.unpack('>IIBBBBB', body)
            need(0 < w <= LIMITS['dimension'] and 0 < h <= LIMITS['dimension'], 'PNG dimensions exceed limits')
            depths = {0:(1,2,4,8,16), 2:(8,16), 3:(1,2,4,8), 4:(8,16), 6:(8,16)}
            need(ctype in depths and depth in depths[ctype] and comp == 0 and filt == 0 and interlace in (0,1), 'Invalid PNG IHDR values')
            channels = {0:1, 2:3, 3:1, 4:2, 6:4}[ctype]
            info = dict(width=w,height=h,bit_depth=depth,color_type=ctype,
                        channel_layout={0:'Gray',2:'RGB',3:'Indexed',4:'GrayAlpha',6:'RGBA'}[ctype],
                        stored_channels=channels,interlace=interlace)
        elif kind == b'PLTE':
            need(palette is None and not idat and ctype not in (0,4) and size % 3 == 0 and 0 < size <= 768, 'Invalid PNG palette')
            palette = size//3
            need(ctype != 3 or palette <= 2**depth, 'PNG palette exceeds bit depth')
        elif kind == b'tRNS':
            need(not trns and not idat and ctype in (0,2,3), 'Invalid PNG tRNS')
            need((ctype == 0 and size == 2) or (ctype == 2 and size == 6) or
                 (ctype == 3 and palette is not None and 0 < size <= palette), 'Invalid PNG tRNS size')
            trns = True
        elif kind in (b'acTL', b'fcTL', b'fdAT'):
            raise Invalid('Animated PNG is outside the static texture inventory scope')
        elif kind == b'IDAT':
            need(not idat_ended and (ctype != 3 or palette is not None), 'Invalid PNG IDAT order/palette')
            idat.append(body)
        elif kind == b'IEND':
            need(size == 0 and idat and pos+12 == len(data), 'Invalid PNG IEND or trailing bytes')
        elif not (kind[0] & 32):
            raise Invalid('Unsupported critical PNG chunk: ' + repr(kind))
        if idat and kind != b'IDAT':
            idat_ended = True
        chunks.append(kind)
        pos += size+12
    need(chunks and chunks[-1] == b'IEND', 'Missing PNG IEND')
    # Adam7 pass shapes, or a single noninterlaced pass. Validate filter bytes and exact scanline size.
    passes = [(0,0,1,1)] if not interlace else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    shapes = []
    for x,y,dx,dy in passes:
        pw,ph = max(0,(w-x+dx-1)//dx), max(0,(h-y+dy-1)//dy)
        if pw and ph:
            shapes.append(((pw*channels*depth+7)//8, ph))
    expected = sum((row+1)*rows for row,rows in shapes)
    need(expected <= LIMITS['png_scanline_bytes'], 'PNG decompressed data exceeds limit')
    try:
        dec = zlib.decompressobj()
        raw = dec.decompress(b''.join(idat), expected+1)
    except zlib.error as exc:
        raise Invalid('PNG invalid zlib stream') from exc
    need(len(raw) == expected and dec.eof and not dec.unconsumed_tail and not dec.unused_data,
         'PNG zlib stream length/termination mismatch')
    cursor = 0
    for row,rows in shapes:
        for _ in range(rows):
            need(raw[cursor] <= 4, 'Invalid PNG row filter')
            cursor += row+1
    info.update(has_alpha_channel=ctype in (4,6), has_transparency_metadata=trns,
                validated_filtered_scanline_bytes=expected,
                native_channel_raster_bytes=((w*channels*depth+7)//8)*h,
                raster_note='Computed packed-row raster size, not an observed decoded allocation; indexed color remains indices.',
                mip_level_count=len(mip_dimensions(w,h)))
    return info


def json_data(data):
    need(len(data) <= LIMITS['json_bytes'], 'JSON exceeds limit')
    def pairs(items):
        out = {}
        for k,v in items:
            need(k not in out, 'Duplicate JSON key: ' + k)
            out[k] = v
        return out
    try:
        return json.loads(data.decode('utf-8'), object_pairs_hook=pairs,
                          parse_constant=lambda x: (_ for _ in ()).throw(Invalid('Nonfinite JSON value')))
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise Invalid('Invalid JSON') from exc


def parse_glb(data):
    need(len(data) >= 20 and len(data) <= LIMITS['member_bytes'], 'Invalid GLB size')
    magic,version,length = struct.unpack_from('<4sII',data)
    need(magic == b'glTF' and version == 2 and length == len(data), 'Invalid GLB header/length')
    pos, chunks = 12, []
    while pos < len(data):
        need(pos+8 <= len(data), 'Truncated GLB chunk')
        n,kind = struct.unpack_from('<II',data,pos)
        need(n % 4 == 0 and pos+8+n <= len(data), 'GLB chunk out of bounds/alignment')
        chunks.append((kind,data[pos+8:pos+8+n]))
        pos += 8+n
    need(chunks and chunks[0][0] == 0x4e4f534a, 'First GLB chunk must be JSON')
    need(sum(k == 0x4e4f534a for k,_ in chunks) == 1 and sum(k == 0x004e4942 for k,_ in chunks) <= 1,
         'Duplicate GLB JSON/BIN chunk')
    j = json_data(chunks[0][1])
    need(isinstance(j,dict) and j.get('asset',{}).get('version') == '2.0', 'Unsupported glTF asset version')
    bin_data = next((b for k,b in chunks if k == 0x004e4942), b'')
    if bin_data:
        need(len(chunks) >= 2 and chunks[1][0] == 0x004e4942, 'GLB BIN must be second chunk')
    buffers = j.get('buffers',[])
    for idx,b in enumerate(buffers):
        n = uint(b.get('byteLength'), 'buffer.byteLength')
        if 'uri' not in b:
            need(idx == 0 and n <= len(bin_data) <= n+3, 'GLB buffer exceeds BIN payload')
    for v in j.get('bufferViews',[]):
        bi = uint(v.get('buffer'), 'bufferView.buffer')
        need(bi < len(buffers), 'GLB buffer index out of bounds')
        start, count = uint(v.get('byteOffset',0),'byteOffset'), uint(v.get('byteLength'),'byteLength')
        need(count > 0 and start+count <= buffers[bi]['byteLength'], 'GLB bufferView out of bounds')
    return j, bin_data


def index(value, arr, name):
    n = uint(value,name)
    need(n < len(arr), name + ' out of bounds')
    return n


def glb_images(data):
    j,bin_data = parse_glb(data)
    imgs, textures, mats = j.get('images',[]),j.get('textures',[]),j.get('materials',[])
    used_materials = set()
    for mesh in j.get('meshes',[]):
        for prim in mesh.get('primitives',[]):
            if 'material' in prim:
                used_materials.add(index(prim['material'],mats,'primitive.material'))
    usages = {i:[] for i in range(len(imgs))}
    unresolved = []
    def walk(node, path, mi):
        if isinstance(node,dict):
            for key,val in node.items():
                sub = path + '.' + key
                if key.lower().endswith('texture') and isinstance(val,dict) and 'index' in val:
                    ti = index(val['index'],textures,'textureInfo.index')
                    texture = textures[ti]
                    if texture.get('extensions'):
                        unresolved.append('Texture '+str(ti)+' has extensions; alternate image sources are not inspected')
                    if 'source' in texture:
                        ii = index(texture['source'],imgs,'texture.source')
                        usages[ii].append(dict(material_index=mi,material_name=mats[mi].get('name',''),
                            slot=sub,texture_index=ti,referenced_by_mesh_primitive=mi in used_materials,
                            alpha_mode=mats[mi].get('alphaMode','OPAQUE')))
                    else:
                        unresolved.append('Texture without core PNG/JPEG source: ' + str(ti))
                else:
                    walk(val,sub,mi)
        elif isinstance(node,list):
            for n,val in enumerate(node):
                walk(val,path+'.'+str(n),mi)
    for mi,m in enumerate(mats):
        walk(m,'materials['+str(mi)+']',mi)
    out = []
    for i,im in enumerate(imgs):
        if 'bufferView' not in im:
            unresolved.append('Image '+str(i)+' has URI/no embedded bufferView; not read or fetched')
            continue
        need('uri' not in im, 'GLB image has both URI and bufferView')
        vi = index(im['bufferView'],j.get('bufferViews',[]),'image.bufferView')
        v = j['bufferViews'][vi]
        if v['buffer'] != 0 or 'uri' in j['buffers'][0]:
            unresolved.append('Image '+str(i)+' refers to an external buffer; not fetched')
            continue
        if im.get('mimeType') != 'image/png':
            unresolved.append('Image '+str(i)+' is not PNG; format '+str(im.get('mimeType')))
            continue
        start = v.get('byteOffset',0)
        raw = bin_data[start:start+v['byteLength']]
        out.append((i,im.get('name','image_'+str(i)),raw,usages[i]))
    return out, dict(materials=mats,mesh_referenced_material_indices=sorted(used_materials),
                     textures=textures,unresolved=unresolved,
                     note='Mesh primitive references are inspected, not scene reachability or runtime residency.')


def role_for(name, usages):
    slots = {u['slot'].rsplit('.',1)[-1] for u in usages}
    if slots:
        if slots == {'normalTexture'}:
            return 'normal', 'GLB material slot'
        if slots == {'baseColorTexture'}:
            return 'base_color', 'GLB material slot'
        if slots == {'metallicRoughnessTexture'}:
            return 'metallic_roughness', 'GLB material slot: roughness G, metallic B'
        return 'mixed_or_other', 'GLB material slots: '+','.join(sorted(slots))
    low = name.lower()
    for needle,role in [('normal','normal'),('basecolor','base_color'),('roughness','roughness')]:
        if needle in low:
            return role, 'Filename hint only; verify source shader/import semantics'
    return 'unknown','No material-role evidence'


def group_exact(occurrences, data_by_id):
    """Hash buckets plus full byte comparison, never filename/pixel similarity."""
    groups = []
    buckets = {}
    for o in occurrences:
        match = None
        for g in buckets.get(o['encoded_sha256'],[]):
            if data_by_id[g['occurrence_ids'][0]] == data_by_id[o['id']]:
                match = g
                break
        if match is None:
            match = {'group_id':'T%03d'%(len(groups)+1),'encoded_sha256':o['encoded_sha256'],
                     'occurrence_ids':[], 'encoded_bytes':o['encoded_bytes']}
            groups.append(match)
            buckets.setdefault(o['encoded_sha256'],[]).append(match)
        match['occurrence_ids'].append(o['id'])
        o['byte_identity_group'] = match['group_id']
    return groups


def summarize(rows):
    known_bc1 = lambda o: o['role'] in ('base_color','roughness','metallic_roughness') and not (
        o['png']['has_alpha_channel'] or o['png']['has_transparency_metadata'])
    return dict(image_resources_assumed=len(rows),
        encoded_png_bytes=sum(o['encoded_bytes'] for o in rows),
        native_channel_raster_base_bytes=sum(o['png']['native_channel_raster_bytes'] for o in rows),
        rgba8_full_mip_payload_bytes=sum(o['formats']['RGBA8']['full_mip_bytes'] for o in rows),
        bc7_full_mip_payload_bytes=sum(o['formats']['BC7']['full_mip_bytes'] for o in rows),
        bc5_normal_bc7_other_full_mip_payload_bytes=sum(o['formats']['BC5' if o['role']=='normal' else 'BC7']['full_mip_bytes'] for o in rows),
        bc5_normal_bc1_opaque_other_bc7_fallback_full_mip_payload_bytes=sum(o['formats']['BC5' if o['role']=='normal' else 'BC1' if known_bc1(o) else 'BC7']['full_mip_bytes'] for o in rows))


def unique_rows(rows):
    seen = set()
    out = []
    for o in rows:
        if o['byte_identity_group'] not in seen:
            out.append(o)
            seen.add(o['byte_identity_group'])
    return out


def read_archive(path, manifest):
    need(path.is_file() and path.stat().st_size <= LIMITS['archive_bytes'], 'Input absent/too large: '+str(path))
    data = path.read_bytes()
    digest = sha(data)
    record = next((r for r in manifest.get('inputs',[]) if r['filename'] == path.name),None)
    if record:
        need(record['sha256'] == digest and record.get('bytes',len(data)) == len(data), 'Baseline input hash/size mismatch: '+path.name)
    archive = dict(filename=path.name,sha256=digest,archive_encoded_bytes=len(data),
                   asset_status=record.get('asset_status','Unspecified') if record else 'Unspecified; no approval inferred',
                   baseline_verified=record is not None)
    blobs = {}
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        need(len(infos) <= LIMITS['members'], 'Too many ZIP members')
        total = 0
        names = set()
        for i in infos:
            safe_name(i.filename)
            need(i.filename not in names, 'Duplicate ZIP member: '+i.filename)
            names.add(i.filename)
            need(not stat.S_ISLNK(i.external_attr >> 16), 'Symlink ZIP member refused')
            need(not i.flag_bits & 1, 'Encrypted ZIP member refused')
            need(i.file_size <= LIMITS['member_bytes'], 'ZIP member exceeds limit')
            total += i.file_size
            need(total <= LIMITS['total_uncompressed_bytes'], 'ZIP expanded size exceeds limit')
            if i.is_dir():
                continue
            # Read data only. Never extract or execute any archived file.
            with z.open(i,'r') as f:
                b = f.read(LIMITS['member_bytes']+1)
            need(len(b) == i.file_size and len(b) <= LIMITS['member_bytes'], 'ZIP member size mismatch')
            blobs[i.filename] = b
        archive.update(zip_member_count=len(infos),zip_members_uncompressed_bytes=total)
    need(sha(path.read_bytes()) == digest, 'Input changed while reading: '+path.name)
    return archive,blobs


def inspect(paths, manifest=None):
    manifest = manifest or {}
    need(0 < len(paths) <= LIMITS['archives'], 'Invalid archive count')
    need(len({str(p.resolve()) for p in paths}) == len(paths), 'Repeated input archive')
    need(len({p.name for p in paths}) == len(paths), 'Input filenames must be distinct')
    archives,occurrences,groups_data,glbs,receipts,unresolved = [],[],{},[],[],[]
    total_expanded = 0
    def add(arch,member,name,raw,kind,usages=None):
        need(len(occurrences) < LIMITS['images'], 'Too many PNG occurrences')
        p = png_info(raw)
        role,basis = role_for(name,usages or [])
        o = dict(id='I%03d'%(len(occurrences)+1),archive=arch,member=member,name=name,kind=kind,
                 encoded_bytes=len(raw),encoded_sha256=sha(raw),png=p,role=role,role_basis=basis,
                 material_usage=usages or [],formats={fmt:allocation(p['width'],p['height'],fmt) for fmt in FORMATS})
        occurrences.append(o)
        groups_data[o['id']] = raw
    for path in paths:
        archive,blobs = read_archive(path,manifest)
        archives.append(archive)
        total_expanded += archive['zip_members_uncompressed_bytes']
        need(total_expanded <= LIMITS['total_uncompressed_bytes'], 'Combined expanded size exceeds limit')
        for name,raw in blobs.items():
            lower = name.lower()
            if lower.endswith('.png'):
                parts = [p.lower() for p in PurePosixPath(name).parts]
                kind = 'source_texture' if 'textures' in parts else 'proof_preview' if any(x in parts for x in ('evidence','previews')) else 'other_png'
                add(path.name,name,PurePosixPath(name).name,raw,kind)
            elif lower.endswith('.glb'):
                images,meta = glb_images(raw)
                glbs.append(dict(archive=path.name,member=name,encoded_sha256=sha(raw),**meta))
                unresolved.extend(path.name+'::'+name+': '+x for x in meta['unresolved'])
                for i,label,im,uses in images:
                    add(path.name,name+'#image['+str(i)+']',label,im,'glb_embedded',uses)
            elif lower.endswith(('.jpg','.jpeg','.ktx','.ktx2','.dds','.webp','.tga','.exr','.tif','.tiff')):
                unresolved.append(path.name+'::'+name+': image format not inspected')
        # Historical source receipts, with fresh archive hash comparisons only.
        for name,raw in blobs.items():
            if PurePosixPath(name).name not in ('MATERIAL_SOURCE_VALIDATION.json','MATERIAL_SOURCE_DEPENDENCY_CHECK.json'):
                continue
            receipt = json_data(raw)
            checks = []
            for im in receipt.get('image_checks',receipt.get('images',[])):
                external = im.get('external',{})
                expected = external.get('sha256',im.get('sha256'))
                matches = [n for n,b in blobs.items() if n.lower().endswith('.png') and sha(b) == expected]
                dims = im.get('dimensions',im.get('decoded',{}).get('size'))
                checks.append(dict(image_name=im.get('image_name',im.get('name')),
                    asserted_sha256=expected,matching_png_members=matches,
                    hash_matches=bool(matches),asserted_dimensions=dims,
                    dimensions_match=bool(matches) and all([png_info(blobs[n])['width'],png_info(blobs[n])['height']]==dims for n in matches) if dims else None,
                    packed_copy_assertion=im.get('packed',im.get('packed_bytes_match_external')),
                    asserted_colorspace=im.get('colorspace',im.get('color_space')),
                    asserted_blender_decoded_channels=im.get('decoded',{}).get('channels')))
            src = receipt.get('source_sha256')
            source_matches = [n for n,b in blobs.items() if n.lower().endswith('.blend') and sha(b)==src]
            receipts.append(dict(archive=path.name,member=name,receipt_sha256=sha(raw),
                                 historical_status=receipt.get('status'),image_hash_checks=checks,
                                 asserted_source_sha256=src,source_hash_matching_members=source_matches,
                                 fresh_blend_opened=False))
    groups = group_exact(occurrences,groups_data)
    by_id = {o['id']:o for o in occurrences}
    # Material-slot evidence transfers only as a byte identity observation, not native import settings.
    for g in groups:
        rows = [by_id[i] for i in g['occurrence_ids']]
        roles = {o['role'] for o in rows if o['material_usage']}
        if len(roles) == 1:
            for o in rows:
                if o['kind'] == 'source_texture' and not o['material_usage']:
                    o['role'] = next(iter(roles))
                    o['role_basis'] = 'Byte-identical to image with inspected GLB material slot'
        g.update(names=sorted({o['name'] for o in rows}),archives=sorted({o['archive'] for o in rows}),
                 kinds=sorted({o['kind'] for o in rows}),width=rows[0]['png']['width'],height=rows[0]['png']['height'])
    source = [o for o in occurrences if o['kind']=='source_texture']
    exported = [o for o in occurrences if o['kind']=='glb_embedded' and any(u['referenced_by_mesh_primitive'] for u in o['material_usage'])]
    union = source+exported
    scenarios = {}
    for name,rows in [('source_files',source),('glb_material_images',exported),('source_plus_glb_packaging_union',union)]:
        scenarios[name+'_separate_per_occurrence'] = summarize(rows)
        scenarios[name+'_shared_by_exact_encoded_bytes'] = summarize(unique_rows(rows))
    per_archive = []
    for a in archives:
        per_archive.append(dict(archive=a['filename'],source_texture_counts=summarize([o for o in source if o['archive']==a['filename']]),
            glb_material_image_counts=summarize([o for o in exported if o['archive']==a['filename']])))
    report = dict(tool_version=VERSION,scope='Read-only inventory and hypothetical texture payload ledger',
        native_validation='NOT_RUN; no performance approval',asset_status_note='Ledger does not alter source, art, contact, export or native qualification status.',
        limits=LIMITS,inputs=archives,cautions=CAUTIONS,format_sources=SOURCES,
        format_assumptions=dict(RGBA8='4 bytes/texel at each level',BC1='8 bytes per rounded-up 4x4 block; opaque RGB/gray/data candidates only, quality unverified',
            BC5='16 bytes per rounded-up 4x4 block; normal XY encoding with shader Z reconstruction assumed, not performed',
            BC7='16 bytes per rounded-up 4x4 block; RGB/RGBA/data candidate, quality unverified',
            mip_chain='Repeated floor-halving each dimension, minimum 1, through 1x1; every BC mip occupies at least one block',
            npot='Arithmetic rounds each level to complete blocks. API/platform dimension restrictions may require resizing or padding; no compatibility approval.'),
        counts=dict(png_occurrences_all=len(occurrences),source_texture_files=len(source),glb_mesh_material_images=len(exported),
                    proof_previews=sum(o['kind']=='proof_preview' for o in occurrences),
                    other_pngs=sum(o['kind']=='other_png' for o in occurrences),
                    glb_images_not_in_mesh_material_totals=sum(o['kind']=='glb_embedded' for o in occurrences)-len(exported),
                    exact_unique_source_textures=len(unique_rows(source)),exact_unique_glb_material_images=len(unique_rows(exported)),
                    exact_unique_source_plus_glb=len(unique_rows(union))),
        scenarios=scenarios,per_archive=per_archive,byte_identity_groups=groups,images=occurrences,
        glb_material_evidence=glbs,historical_source_receipts=receipts,unresolved=unresolved,
        inventory_complete_for_supported_scope=not unresolved)
    return report


def markdown(report):
    r = report
    lines = ['# YourQuest shared-texture payload ledger','',
      '**Hypothetical payload arithmetic only. No Unity run, VRAM measurement, frame-time claim, or approval.**','',
      '## What the three compact packs contain','',
      f"- Source texture files: {r['counts']['source_texture_files']}; exact byte-unique images: {r['counts']['exact_unique_source_textures']}.",
      f"- GLB mesh-material images: {r['counts']['glb_mesh_material_images']}; exact byte-unique images: {r['counts']['exact_unique_glb_material_images']}.",
      f"- Source + export union: {r['counts']['exact_unique_source_plus_glb']} exact byte-unique images. This union is a packaging inventory, not a runtime loading plan.",
      f"- Excluded from material totals: {r['counts']['proof_previews']} proof previews, {r['counts']['other_pngs']} other PNGs, and {r['counts']['glb_images_not_in_mesh_material_totals']} unreferenced embedded images.",'',
      '## Full-mip texture payload scenarios','',
      'MiB = 1,048,576 bytes. Tight texture-data payload only, excluding allocation overhead and all other resources.','',
      '| Scope / sharing assumption | Images | Encoded PNG MiB | RGBA8 MiB | BC7 / BC5 normals MiB | BC1 opaque / BC5 normals / BC7 fallback MiB |',
      '|---|---:|---:|---:|---:|---:|']
    for name,v in r['scenarios'].items():
        lines.append('| '+name.replace('_',' ')+' | '+str(v['image_resources_assumed'])+' | '+' | '.join(f'{v[k]/MIB:.6f}' for k in ['encoded_png_bytes','rgba8_full_mip_payload_bytes','bc5_normal_bc7_other_full_mip_payload_bytes','bc5_normal_bc1_opaque_other_bc7_fallback_full_mip_payload_bytes'])+' |')
    lines += ['','Encoded PNG sums above count image representations before outer ZIP compression; they are neither ZIP download size nor GPU allocation.',
      'Shared rows assume one compatible resource per exact byte-identity group. Separate rows assume one resource per occurrence in that scope; neither is measured residency.',
      'BC5 normals require an XY normal-map import/shader convention with reconstructed Z. BC1 is a hypothetical lossy candidate for opaque color/data, including grayscale roughness; this does not establish acceptable visual/data quality. BC4 is not modeled.','',
      '## Unique material representations','',
      '| Group | PNG names | Dimensions / channels | Encoded bytes | Occurrences | Roles |',
      '|---|---|---|---:|---:|---|']
    for g in r['byte_identity_groups']:
        rows = [o for o in r['images'] if o['byte_identity_group']==g['group_id'] and o['kind'] in ('source_texture','glb_embedded')]
        if rows:
            p = rows[0]['png']
            lines.append(f"| {g['group_id']} | {'; '.join(g['names'])} | {p['width']}×{p['height']} {p['channel_layout']} {p['bit_depth']}-bit | {g['encoded_bytes']} | {len(rows)} | {'; '.join(sorted({o['role'] for o in rows}))} |")
    lines += ['','PNG channels come from IHDR. A historical Blender receipt may say four decoded channels for an RGB PNG; that is a different representation.',
      'Different encoded hashes remain separate. In particular, do not equate a source roughness grayscale PNG with an export metallic/roughness PNG merely because their names match. glTF roughness is read from G and metallic from B.','',
      '## Input integrity and status','']
    for a in r['inputs']:
        lines += [f"- {a['filename']}",f"  - SHA-256: `{a['sha256']}`",f"  - Archive bytes: {a['archive_encoded_bytes']}; baseline verified: {a['baseline_verified']}",f"  - Status: **{a['asset_status']}**"]
    lines += ['','## Limits and interpretation','']+['- '+x for x in r['cautions']]
    lines += ['','## Unresolved coverage','']+(['- '+x for x in r['unresolved']] or ['None in these three inputs for the supported PNG / embedded-PNG GLB inventory.'])
    lines += ['','## Reuse decision before native integration','',
      '1. Compare texture identity groups and inspect the recorded GLB material slots.',
      '2. Choose one source or export import path, then deliberately share compatible texture assets where appropriate.',
      '3. Verify sRGB versus linear data, normal-map settings/convention, mip policy, target compression and quality.',
      '4. Inspect actual native texture references, formats, dimensions, residency and profiler allocations before any hardware-budget conclusion.',
      '5. Keep CONTACT_HELD / limited-WIP gates independent of these storage calculations.','',
      '## References','']+['- '+s for s in r['format_sources']]
    return '\n'.join(lines)+'\n'


def write_report(report, out):
    need(not out.exists(), 'Output directory already exists; refusing to overwrite')
    out.mkdir(parents=True)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    (out/'report.md').write_text(markdown(report),encoding='utf-8')
    fields = ['id','archive','member','kind','role','role_basis','byte_identity_group','encoded_sha256','encoded_bytes',
              'width','height','channel_layout','stored_channels','bit_depth','native_channel_raster_bytes',
              'rgba8_full_mip_bytes','bc1_full_mip_bytes','bc5_full_mip_bytes','bc7_full_mip_bytes']
    with (out/'images.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=fields)
        writer.writeheader()
        for o in report['images']:
            row = {k:o[k] for k in fields if k in o}
            row.update({k:o['png'][k] for k in fields if k in o['png']})
            row.update({fmt.lower()+'_full_mip_bytes':o['formats'][fmt]['full_mip_bytes'] for fmt in FORMATS})
            # Neutralize spreadsheet formula prefixes in user-controlled text only.
            row = {k: "'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v for k,v in row.items()}
            writer.writerow(row)
    with (out/'scenarios.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=['scenario']+list(next(iter(report['scenarios'].values())).keys()))
        writer.writeheader()
        for name,vals in report['scenarios'].items():
            writer.writerow(dict(scenario=name,**vals))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('archives',nargs='+',type=Path)
    ap.add_argument('--out',required=True,type=Path,help='New output directory; must not exist')
    ap.add_argument('--manifest',type=Path,help='Optional exact-hash input baseline/status manifest')
    args = ap.parse_args(argv)
    try:
        need(not args.out.exists(), 'Output directory already exists; refusing to overwrite')
        manifest = json_data(args.manifest.read_bytes()) if args.manifest else {}
        report = inspect(args.archives,manifest)
        write_report(report,args.out)
        print('Wrote '+str(args.out)+'; '+str(report['counts']['exact_unique_source_plus_glb'])+' exact unique material representations. No native-performance claim.')
        return 0 if report['inventory_complete_for_supported_scope'] else 3
    except (Invalid,OSError,zipfile.BadZipFile,RuntimeError,KeyError,TypeError,IndexError,AttributeError,RecursionError) as exc:
        print('ERROR: '+str(exc),file=sys.stderr)
        return 2

if __name__ == '__main__':
    sys.exit(main())
