# YourQuest shared-texture budget helper

A small, Python-standard-library CLI for reading ZIP-contained PNGs and PNG images embedded in GLB exports. It inventories actual encoded images, proves byte identity, and calculates explicitly hypothetical full-mip texture payloads. It never opens Blender, Unity, or a GPU and never changes an input archive.

Start with `report/report.md`. Exact hashes, image/material links and per-mip arithmetic are in `report/report.json`; `report/images.csv` and `report/scenarios.csv` are spreadsheet-friendly ledgers.

## Findings in these three packs

- Bank toe crescent and boulder lee deposit contain the same two 1024×1024 RGB PNGs, byte for byte. Their GLBs embed those same PNG bytes.
- Root triplet has three different 1024×1024 source maps. Base color and normal also match their embedded GLB bytes. Source roughness is grayscale; the GLB's metallic/roughness image is RGB and has different bytes. It remains a separate identity; this tool does not compare or canonicalize decoded pixels.
- Seven source texture files give five unique encoded images. Seven GLB mesh-material images also give five unique encoded images. Their packaging union gives six, because source and exported roughness are different representations. Ten proof previews are excluded from material totals.
- At a hypothetical one-compatible-resource-per-identity, five-image, full-mip import: RGBA8 payload is 27,962,020 bytes (26.666660 MiB). BC7 for other maps / BC5 for normals is 6,990,640 bytes (6.666794 MiB). Neither number is measured memory usage or a statement of importer behavior.
- The separate BC1/BC5 scenario is an arithmetic comparison only. BC1 is not recommended for roughness or color on payload size alone; normal reconstruction, color/data precision, artifacts, target support and actual import settings remain untested. BC4 is deliberately outside this small ledger.

Bank toe remains **CONTACT_HELD / limited WIP**. Lee and root triplet remain **limited WIP**. The ledger changes no art, contact, export or native approval.

## Run it

Requires Python 3.9+; no packages to install. Put this helper folder anywhere and retain your three original input ZIPs. Use their real paths, without extracting them:

```sh
python texture_budget.py --manifest input_manifest.json --out fresh_report \
  /path/to/YourQuest_BankToeCrescent_LOD0_Source_GLB_20261015_0527.zip \
  /path/to/YourQuest_BoulderLeeDeposit_LOD0_Source_GLB_20261015_0553.zip \
  /path/to/YourQuest_YQ_17_09_SurfaceRootTriplet_SourceWIP_LOD0_20261015.zip
```

On Windows, use `py -3` if needed and put the command on one line. Output must be a new directory; existing reports are never overwritten. `--manifest` verifies the supplied archives against the recorded exact baseline hashes and carries forward their task-context statuses. Omit it for other ZIPs; their status is then unspecified and no approval is inferred.

```sh
python -m unittest -v test_texture_budget
```

Exit codes: 0 = supported inventory complete; 2 = invalid input/limit/error; 3 = report written with unresolved image coverage. Do not treat an incomplete report as a total asset budget. The helper does not extract archive members, execute archived scripts, follow links, fetch URLs, modify import settings, or alter any source files.

## What is measured and what is assumed

Measured from bytes: input SHA-256 and length; PNG dimensions, stored channels and bit depth; encoded PNG byte count/hash; CRCs and bounded zlib scanline structure; GLB JSON material slots and bounded embedded-image slices. Equal SHA-256 is followed by full byte comparison before deduplication.

Calculated: native-channel packed-row raster size and format payloads. RGBA8 is four bytes per texel. BC1 uses eight bytes per 4×4 block; BC5/BC7 use sixteen. Each mip floors width and height independently, clamping to one, through 1×1. BC blocks round up at every level, including tiny and non-power-of-two levels. API dimension restrictions may still require padding/resizing. Actual compression is not performed.

Historical evidence: source receipts' external-image hashes/dimensions and .blend hashes match the supplied archive bytes. Packed-image/source-shader assertions remain historical; .blend and FBX contents are not freshly opened or parsed. Material roles for byte-identical maps can be cross-referenced to inspected GLB slots. The unmatched source roughness role is explicitly a filename hint, corroborated in the archived source receipt only as an image dependency.

Exact byte identity is a lower-bound opportunity to share resources. It does not prove Unity shares them: differing asset identities, color spaces, normal settings or other importer decisions may duplicate the same bytes. A source+export union does not imply both load at runtime. The separate-per-occurrence scenarios are hypothetical too, not measured upper bounds on allocations.

Hardware context is an 8 GB VRAM-class device. None of that capacity is assumed free or available. Other textures, render targets, geometry, driver alignment, CPU copies, upload staging, streaming and other processes are outside this ledger. There is no VRAM peak or frame-time result.

## Safety bounds and coverage

Limits: 16 input ZIPs; 256 MiB per ZIP; 4,096 members per ZIP; 64 MiB per member; 512 MiB summed expanded member sizes; 4 MiB per JSON; 1,024 PNG occurrences; maximum dimension 16,384; 128 MiB filtered PNG scanline data per image. Limits are fixed in the small script, rather than bypass switches. Paths with traversal, absolute paths, backslashes, drive prefixes, duplicate member names and symlink entries are refused. No archived content is extracted or executed. Inputs are hash-checked again after reading. Output CSV text neutralizes spreadsheet formula prefixes.

PNG bounds, checksums, zlib termination, row sizes and filter identifiers are checked; this is not a complete format conformance/pixel decoder. Animation is rejected. GLB chunk/buffer/image bounds and used material/texture/image references are checked; this is not a general scene/geometry validator. URI-backed images, unsupported image formats and alternate texture-source extensions are disclosed as unresolved and never fetched. Mesh references do not establish active-scene reachability or loaded residency.

The packaged tests cover analytical 1×1, sub-block, non-power-of-two, narrow, 1K and full-mip cases; PNG malformed input; GLB bounds; dedup across archives/embedded images; separately encoded equal pixels; hypothetical hash collisions; ZipSlip/symlink/size/member limits; no extraction or input changes; and report output.

## References

- [Microsoft: BC format block sizes](https://learn.microsoft.com/en-us/windows/win32/direct3d11/texture-block-compression-in-direct3d-11)
- [Khronos glTF 2.0: GLB images and material channels](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html)
- [W3C PNG specification](https://www.w3.org/TR/png-3/)

These references document format conventions. They do not validate this user's native renderer, art, contact or hardware performance.
