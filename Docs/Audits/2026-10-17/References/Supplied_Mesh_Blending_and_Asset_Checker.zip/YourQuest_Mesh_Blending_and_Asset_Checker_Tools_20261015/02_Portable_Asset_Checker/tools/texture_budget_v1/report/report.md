# YourQuest shared-texture payload ledger

**Hypothetical payload arithmetic only. No Unity run, VRAM measurement, frame-time claim, or approval.**

## What the three compact packs contain

- Source texture files: 7; exact byte-unique images: 5.
- GLB mesh-material images: 7; exact byte-unique images: 5.
- Source + export union: 6 exact byte-unique images. This union is a packaging inventory, not a runtime loading plan.
- Excluded from material totals: 10 proof previews, 0 other PNGs, and 0 unreferenced embedded images.

## Full-mip texture payload scenarios

MiB = 1,048,576 bytes. Tight texture-data payload only, excluding allocation overhead and all other resources.

| Scope / sharing assumption | Images | Encoded PNG MiB | RGBA8 MiB | BC7 / BC5 normals MiB | BC1 opaque / BC5 normals / BC7 fallback MiB |
|---|---:|---:|---:|---:|---:|
| source files separate per occurrence | 7 | 4.931314 | 37.333324 | 9.333511 | 6.666794 |
| source files shared by exact encoded bytes | 5 | 2.531765 | 26.666660 | 6.666794 | 4.666756 |
| glb material images separate per occurrence | 7 | 4.960924 | 37.333324 | 9.333511 | 6.666794 |
| glb material images shared by exact encoded bytes | 5 | 2.561376 | 26.666660 | 6.666794 | 4.666756 |
| source plus glb packaging union separate per occurrence | 14 | 9.892238 | 74.666649 | 18.667023 | 13.333588 |
| source plus glb packaging union shared by exact encoded bytes | 6 | 2.587873 | 31.999992 | 8.000153 | 5.333435 |

Encoded PNG sums above count image representations before outer ZIP compression; they are neither ZIP download size nor GPU allocation.
Shared rows assume one compatible resource per exact byte-identity group. Separate rows assume one resource per occurrence in that scope; neither is measured residency.
BC5 normals require an XY normal-map import/shader convention with reconstructed Z. BC1 is a hypothetical lossy candidate for opaque color/data, including grayscale roughness; this does not establish acceptable visual/data quality. BC4 is not modeled.

## Unique material representations

| Group | PNG names | Dimensions / channels | Encoded bytes | Occurrences | Roles |
|---|---|---|---:|---:|---|
| T003 | YQ_OriginalCoolBrownStone_Normal; YQ_OriginalCoolBrownStone_Normal.png | 1024×1024 RGB 8-bit | 1432567 | 4 | normal |
| T004 | YQ_OriginalCoolBrownStone_BaseColor; YQ_OriginalCoolBrownStone_BaseColor.png | 1024×1024 RGB 8-bit | 1083542 | 4 | base_color |
| T011 | YQ_BankRootQuiet_NormalGL; YQ_BankRootQuiet_NormalGL.png | 1024×1024 RGB 8-bit | 54150 | 2 | normal |
| T012 | YQ_BankRootQuiet_BaseColor; YQ_BankRootQuiet_BaseColor.png | 1024×1024 RGB 8-bit | 56704 | 2 | base_color |
| T013 | YQ_BankRootQuiet_Roughness | 1024×1024 RGB 8-bit | 58834 | 1 | metallic_roughness |
| T016 | YQ_BankRootQuiet_Roughness.png | 1024×1024 Gray 8-bit | 27785 | 1 | roughness |

PNG channels come from IHDR. A historical Blender receipt may say four decoded channels for an RGB PNG; that is a different representation.
Different encoded hashes remain separate. In particular, do not equate a source roughness grayscale PNG with an export metallic/roughness PNG merely because their names match. glTF roughness is read from G and metallic from B.

## Input integrity and status

- YourQuest_BankToeCrescent_LOD0_Source_GLB_20261015_0527.zip
  - SHA-256: `62afd31ade973363e537e89851a2d37f15cb915f94808f1cd4a84aeb37ffcffa`
  - Archive bytes: 9234975; baseline verified: True
  - Status: **CONTACT_HELD; limited WIP**
- YourQuest_BoulderLeeDeposit_LOD0_Source_GLB_20261015_0553.zip
  - SHA-256: `7bfd96f4e8897091f0be08c22d72f13d5ce172983f03a7eca2255c480da2e018`
  - Archive bytes: 12155660; baseline verified: True
  - Status: **Limited WIP**
- YourQuest_YQ_17_09_SurfaceRootTriplet_SourceWIP_LOD0_20261015.zip
  - SHA-256: `f16261288c2c0972569597fa076a9ed0f4b3cbf7f9cf4b02ac4213eb4351a5e5`
  - Archive bytes: 2094819; baseline verified: True
  - Status: **Limited WIP**

## Limits and interpretation

- No Unity import, player, profiler, GPU, or Blender was run. No VRAM/performance or art/contact approval.
- The user reported an 8 GB VRAM-class device. That is not a free-memory budget; no availability or utilization is inferred.
- PNG encoded bytes, native-channel raster-size arithmetic, and assumed GPU-format payload bytes are different quantities.
- Exact deduplication requires SHA-256 AND byte-for-byte equality. Differently encoded images remain separate even if their pixels might match.
- Byte identity is a lower-bound shared-resource opportunity, not proof of importer sharing. Different settings, color spaces, samplers, containers, or asset GUIDs can create separate resources.
- All budget rows are tight 2D texture-data payload scenarios with full mip chains; no API/driver alignment, metadata, staging, CPU copies, streaming, render targets, geometry, or other allocations are included.
- BC rows are representation-size calculations, not a compression or quality test. Device/API support, source semantics, normal convention, import settings, resizing and quality require native validation.
- Preview/evidence PNGs are inventoried separately and excluded from material totals. Source+GLB union is a packaging superset, not a statement that both representations load together.
- Source receipts are historical assertions, not a fresh .blend inspection. Only stated receipt hashes/dimensions and source file hashes are compared to current archive bytes.
- Unsupported image types and URI-backed GLB images are reported as unresolved. This is a bounded inventory, not a complete PNG or glTF conformance validator.

## Unresolved coverage

None in these three inputs for the supported PNG / embedded-PNG GLB inventory.

## Reuse decision before native integration

1. Compare texture identity groups and inspect the recorded GLB material slots.
2. Choose one source or export import path, then deliberately share compatible texture assets where appropriate.
3. Verify sRGB versus linear data, normal-map settings/convention, mip policy, target compression and quality.
4. Inspect actual native texture references, formats, dimensions, residency and profiler allocations before any hardware-budget conclusion.
5. Keep CONTACT_HELD / limited-WIP gates independent of these storage calculations.

## References

- https://learn.microsoft.com/en-us/windows/win32/direct3d11/texture-block-compression-in-direct3d-11
- https://registry.khronos.org/DataFormat/specs/1.4/dataformat.1.4.html
- https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
- https://www.w3.org/TR/png-3/
