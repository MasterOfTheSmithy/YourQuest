#!/usr/bin/env python3
"""Reproduce the immutable bank-toe defect; regression success keeps contact FAIL."""
import argparse
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile

from exact_contact import load_input, preflight
from extract_bank_toe import extract

ROOT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def replay(source_root=None):
    path=ROOT/'fixtures/bank_toe.json'
    provenance_path=ROOT/'fixtures/bank_toe_provenance.json'
    archive_path=ROOT/'fixtures/archived_contact_verification.json'
    provenance=json.loads(provenance_path.read_text())
    archive=json.loads(archive_path.read_text())
    source_check='BUNDLED_EXTRACTED_FIXTURE_ONLY'
    if source_root:
        for row in provenance['source_files'].values():
            if sha(source_root/row['relative_path']) != row['sha256']:
                raise ValueError('Immutable source hash mismatch: '+row['relative_path'])
        with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()):
            target=Path(td)
            extract(source_root,target)
            if (target/'bank_toe.json').read_bytes()!=path.read_bytes():
                raise ValueError('Re-extracted case differs from bundled fixture')
            if (target/'bank_toe_provenance.json').read_bytes()!=provenance_path.read_bytes():
                raise ValueError('Re-extracted provenance differs from bundled provenance')
        source_check='PASS_ALL_NINE_SOURCE_HASHES_AND_FRESH_READ_ONLY_EXTRACTION'
    result=preflight(load_input(path))
    if result['status']!='FAIL' or result['coverage_status']!='PASS':
        raise ValueError('Expected complete coverage and preserved contact FAIL')
    failures=sorted({r['component'] for r in result['faces'] if r['covered_gap_status']=='FAIL'})
    if failures!=['clast_02']:
        raise ValueError('Unexpected failing component set')
    if result['gap_limits_m']!=archive['support_limits_m']:
        raise ValueError('Contact limits changed')
    current=[result['minimum']['gap_m'],result['maximum']['gap_m']]
    old=archive['global_bottom_gap_range_m']
    differences=[a-b for a,b in zip(current,old)]
    if max(abs(v) for v in differences)>1e-12:
        raise ValueError('Archive extrema cross-check failed')
    w=result['maximum']; aw=archive['witness']
    if (w['underside_face_id'],w['host_face_id'])!=(aw['clast_triangle_global'],aw['host_triangle']):
        raise ValueError('Archive maximum witness IDs changed')
    if max(abs(a-b) for a,b in zip(w['xy_m'],aw['xy_m']))>1e-12:
        raise ValueError('Archive maximum witness coordinates changed')
    component_deltas=[]
    for archived in archive['rows']:
        faces=[f for f in result['faces'] if f['component']==archived['id']]
        bounds=[min(f['minimum']['gap_m'] for f in faces),max(f['maximum']['gap_m'] for f in faces)]
        deltas=[a-b for a,b in zip(bounds,archived['bottom_gap_range_m'])]
        if max(abs(v) for v in deltas)>1e-12:
            raise ValueError('Archive per-component extrema cross-check failed')
        component_deltas.append({'component':archived['id'],'exact_gap_range_m':bounds,'delta_from_archived_float_report_m':deltas})
    sparse=provenance['historical_sparse_sample_ranges_m']
    if not all(-.008<=lo<=hi<=.003 for lo,hi in sparse.values()):
        raise ValueError('Expected historical sparse-sampling PASS evidence')
    return {'schema':'yq_bank_toe_exact_replay_v1','regression_status':'PASS_REPRODUCED_KNOWN_CONTACT_FAILURE',
            'contact_status':'FAIL','source_verification':source_check,
            'summary':{'gap_range_mm':[v*1000 for v in current],
                       'upper_limit_mm':3,'upper_limit_excess_mm':(current[1]-.003)*1000,
                       'failing_components':failures,'original_sparse_samples_passed':True,
                       'candidate_underside_identical':provenance['candidate_underside_vertices_and_connectivity_identical'],
                       'minimum':result['minimum'],'maximum':w},
            'archive_cross_check':{'status':'PASS','absolute_comparison_tolerance_m':1e-12,
                                  'range_delta_m':differences,'components':component_deltas,
                                  'archive_sha256':sha(archive_path)},
            'input_sha256':sha(path),'provenance_sha256':sha(provenance_path),
            'assets_changed':False,'old_receipts_changed':False,'blender_run':False,'native':'NOT_RUN',
            'contact_report':result}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,help='Optional immutable benchmark evidence root; rechecks all source hashes and extraction')
    parser.add_argument('--output',type=Path,help='New report file, never overwritten')
    args=parser.parse_args()
    try:
        payload=json.dumps(replay(args.source_root),sort_keys=True,indent=2,allow_nan=False)+'\n'
        if args.output:
            with args.output.open('x') as f:
                f.write(payload)
        else:
            print(payload,end='')
        return 0
    except (ValueError,OSError) as exc:
        print(json.dumps({'regression_status':'UNVERIFIED','error':str(exc)}))
        return 2


if __name__=='__main__':
    raise SystemExit(main())
