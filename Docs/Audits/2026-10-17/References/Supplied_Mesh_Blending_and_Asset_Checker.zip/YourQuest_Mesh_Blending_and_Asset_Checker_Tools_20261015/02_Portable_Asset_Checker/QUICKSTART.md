# YourQuest portable asset preflight toolkit v1

Three independent, read-only CPU helpers in one ZIP. Unzip it anywhere, including
a path containing spaces. You need an **existing Python 3.10+** interpreter. Python
itself is not bundled. No package installation, network, Blender, Unity, GPU,
or original model ZIP is needed to run the tests and two actual-case replays.

## Start here

Open a terminal in this folder and run:

```sh
python toolkit.py list
python toolkit.py test all
```

On systems using `python3`, replace `python` with `python3`. On Windows, the
equivalent command is `py -3 toolkit.py test all`, if that launcher is installed.
The launcher always uses the same Python interpreter that started it. Paths are
resolved from the toolkit file, so it also works when called from another folder:

```sh
python "/path with spaces/YourQuest_Portable_Asset_Preflight_Toolkit_V1_20261015/toolkit.py" test all
```

You can run a single suite with `test contact`, `test association`, or `test texture`.
`test all` runs **123 helper tests: 43 contact + 30 association + 50 texture**.
The separate, small launcher suite has **11 tests**:

```sh
python -B -S -m unittest discover -s tests -v
```

The helper suites run in separate child processes, each with its own helper
directory as the working directory. They do not share imported modules. The
launcher disables bytecode writing and site-package loading for those processes.
Tests create temporary synthetic data as needed; they do not alter bundled input
fixtures, existing reports, or original model files.

## Replay the bundled actual evidence

```sh
python toolkit.py replay contact
python toolkit.py replay association
```

These print reports and launcher status lines to the terminal. `replay all` runs
both. To obtain pure JSON, run each helper directly as documented in its README;
the launcher's mixed output is intended for a person, not JSON parsing.

- **Contact:** successful regression means it reproduces the known bank-toe
  **contact FAIL**. Maximum gap is +3.596424 mm against the unchanged +3 mm limit.
  It does not repair or approve the model.
- **Association:** successful replay covers **22 recorded imported witnesses**
  against **884 source candidates**. Coverage is **PARTIAL**; 862 imported
  triangles are not replayed. It does not check UVs, normals, tangents, materials,
  or native behavior.
- **Texture:** the 50 tests use synthetic temporary inputs. They work without the
  original model packs. The historical ledger under `tools/texture_budget_v1/report/`
  contains theoretical payload scenarios, not measured VRAM or performance.

## Regenerate the actual texture ledger

The original three model ZIPs are deliberately **not bundled**. Regenerating their
ledger requires all three exact packs listed below. From
`tools/texture_budget_v1`, run this as one line, replacing the quoted example paths:

```sh
python texture_budget.py --manifest input_manifest.json --out "fresh ledger" "/packs/YourQuest_BankToeCrescent_LOD0_Source_GLB_20261015_0527.zip" "/packs/YourQuest_BoulderLeeDeposit_LOD0_Source_GLB_20261015_0553.zip" "/packs/YourQuest_YQ_17_09_SurfaceRootTriplet_SourceWIP_LOD0_20261015.zip"
```

The output directory must be new. The manifest verifies exact input hashes.
Do not substitute the small helper ZIPs for the original model ZIPs. Optional
rechecking of contact/association provenance against original source directories
is described in each helper README; bundled replay alone does not reopen those
originals or newly verify their hashes.

## Exit codes and scope

The launcher exits 0 when all selected software tests/replays finish successfully,
1 when any selected child fails, 2 for invalid arguments or unsupported Python,
and 130 when interrupted. It continues the remaining selected helpers after a
normal child failure. A launcher exit 0 is **never a combined asset PASS**.

The direct contact CLI has different asset-result codes: 0 PASS, 1 FAIL,
2 UNVERIFIED. Thus the bank-toe direct contact check is expected to exit 1, while
the regression replay exits 0 for correctly detecting that failure. See the
original READMEs for other direct helper exit codes.

Linux / CPython 3.12.14 was tested from a clean extraction in a path containing
spaces, with no site packages required. Windows commands and path handling are
portable intent only: **Windows was not run or certified**. Other Python versions
and operating systems were not tested. No native/art/performance approval is
established. Read `DECISION_GUIDE.md` before interpreting results.

## Package contents

- `toolkit.py`: small stdlib launcher; no installer or dependency bootstrap
- `tools/contact_v1/`: unchanged exact-contact v1 helper and fixtures
- `tools/association_v1/`: unchanged position-association v1 helper and fixture
- `tools/texture_budget_v1/`: unchanged budget-ledger helper and historical reports
- `tests/test_toolkit.py`: launcher-only regression tests
- `INPUTS.json`: frozen upstream archive identities and byte-for-byte file mapping
- `VERIFICATION.json`: portable-package verification and limitations
- `SHA256SUMS.json`: all packaged files except this checksum file
- `NOTICES.md`: original-document and licensing preservation

The three helper folders remain independently runnable. Their original source,
tests, fixtures, notices and documentation are preserved byte for byte.
