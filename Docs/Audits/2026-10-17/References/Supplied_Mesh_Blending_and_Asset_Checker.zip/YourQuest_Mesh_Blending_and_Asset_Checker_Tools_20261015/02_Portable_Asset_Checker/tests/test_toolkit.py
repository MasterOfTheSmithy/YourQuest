"""Small launcher checks; the original helper suites remain independent."""

import contextlib
import io
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import toolkit


class LauncherTests(unittest.TestCase):
    def call_main(self, arguments):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return toolkit.main(arguments)

    def test_list_without_running_tools(self):
        with patch.object(toolkit.subprocess, "run") as runner:
            self.assertEqual(self.call_main(["list"]), 0)
            runner.assert_not_called()

    def test_one_test_tool(self):
        with patch.object(toolkit, "run_tool", return_value=0) as runner:
            self.assertEqual(self.call_main(["test", "texture"]), 0)
            runner.assert_called_once_with("texture", "test")

    def test_default_runs_all(self):
        with patch.object(toolkit, "run_tool", return_value=0) as runner:
            self.assertEqual(self.call_main(["test"]), 0)
            self.assertEqual([call.args for call in runner.call_args_list],
                             [(name, "test") for name in toolkit.TOOLS])

    def test_failure_continues_other_helpers_and_is_nonzero(self):
        with patch.object(toolkit, "run_tool", side_effect=[1, 0, 0]) as runner:
            self.assertEqual(self.call_main(["test", "all"]), 1)
            self.assertEqual(runner.call_count, 3)

    def test_replay_all_excludes_texture_regeneration(self):
        with patch.object(toolkit, "run_tool", return_value=0) as runner:
            self.assertEqual(self.call_main(["replay", "all"]), 0)
            self.assertEqual([call.args for call in runner.call_args_list],
                             [("contact", "replay"), ("association", "replay")])

    def test_subprocess_uses_current_python_helper_cwd_no_shell(self):
        with patch.object(toolkit.subprocess, "run", return_value=subprocess.CompletedProcess([], 0)) as runner:
            self.assertEqual(self.call_main(["test", "contact"]), 0)
            args, kwargs = runner.call_args
            self.assertEqual(args[0], [sys.executable, "-B", "-S", "-m", "unittest", "discover", "-s", "tests", "-v"])
            self.assertEqual(kwargs["cwd"], toolkit.ROOT / "tools" / "contact_v1")
            self.assertEqual(kwargs["env"]["PYTHONDONTWRITEBYTECODE"], "1")
            self.assertFalse(kwargs.get("shell", False))
            self.assertFalse(kwargs["check"])

    def test_missing_directory_fails(self):
        with patch.object(Path, "is_dir", return_value=False), patch.object(toolkit.subprocess, "run") as runner:
            self.assertEqual(self.call_main(["test", "association"]), 1)
            runner.assert_not_called()

    def test_launch_error_fails(self):
        with patch.object(toolkit.subprocess, "run", side_effect=OSError("test launch error")):
            self.assertEqual(self.call_main(["test", "texture"]), 1)

    def test_old_python_refused(self):
        with patch.object(toolkit.sys, "version_info", (3, 9)), self.assertRaises(SystemExit) as error:
            self.call_main(["test", "all"])
        self.assertEqual(error.exception.code, 2)

    def test_unknown_tool_refused(self):
        with self.assertRaises(SystemExit) as error:
            self.call_main(["test", "../other"])
        self.assertEqual(error.exception.code, 2)

    def test_texture_replay_not_advertised(self):
        with self.assertRaises(SystemExit) as error:
            self.call_main(["replay", "texture"])
        self.assertEqual(error.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
